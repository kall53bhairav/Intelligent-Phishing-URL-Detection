"""
main.py
-------
End-to-end phishing URL detection pipeline.

Steps:
  1. Load (or generate) the labeled URL dataset.
  2. Extract lexical / structural / host-based features.
  3. Run EDA (saves plots + prints class-separating stats).
  4. Feature selection (correlation pruning + ANOVA + RF importance).
  5. Train Logistic Regression, Decision Tree, Random Forest, SVM.
  6. Evaluate with Precision, Recall, F1-score, ROC-AUC (+ plots).
  7. Print a ranked summary and demo predictions.

Usage:
    python main.py                       # uses/creates data/urls.csv
    python main.py --data path/to.csv    # your own [url,label] csv
"""
import argparse
import os
import pandas as pd
from sklearn.model_selection import train_test_split

from features import featurize_frame, extract_features, FEATURE_NAMES
from eda import run_eda
from feature_selection import select_features
from models import train_and_evaluate

DATA_PATH = "data/urls.csv"


def load_data(path):
    if not os.path.exists(path):
        print(f"[data] {path} not found -> generating synthetic dataset")
        from generate_dataset import build_dataset
        os.makedirs(os.path.dirname(path), exist_ok=True)
        build_dataset().to_csv(path, index=False)
    df = pd.read_csv(path)
    assert {"url", "label"}.issubset(df.columns), "csv needs [url,label] columns"
    return df


def demo_predictions(model, feature_cols):
    samples = [
        ("https://www.github.com/features", 0),
        ("https://www.paypal.com/account/settings", 0),
        ("http://paypal.com@193.44.2.9/secure/login?verify=1", 1),
        ("http://secure-appleid.verify-account.xyz/confirm?id=x9f2", 1),
        ("http://update-amazon.billing.login.tk/webscr?cmd=_signin", 1),
    ]
    print("\n=== DEMO PREDICTIONS (best model) ===")
    rows = []
    for url, true in samples:
        feats = extract_features(url)
        X = pd.DataFrame([feats])[feature_cols]
        pred = int(model.predict(X)[0])
        try:
            prob = float(model.predict_proba(X)[0, 1])
        except AttributeError:
            prob = float("nan")
        rows.append({"url": url[:60], "true": true, "pred": pred,
                     "phish_prob": round(prob, 3)})
    print(pd.DataFrame(rows).to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=DATA_PATH)
    ap.add_argument("--test-size", type=float, default=0.2)
    args = ap.parse_args()

    # 1) data --------------------------------------------------------------
    df = load_data(args.data)
    print(f"[data] {len(df)} URLs | class balance:\n"
          f"{df['label'].value_counts().rename({0:'legit',1:'phishing'}).to_string()}")

    # 2) features ----------------------------------------------------------
    X = featurize_frame(df, url_col="url")
    y = df["label"].astype(int)
    print(f"[features] extracted {X.shape[1]} features for {X.shape[0]} URLs")

    # 3) EDA ---------------------------------------------------------------
    run_eda(X, y)

    # 4) feature selection -------------------------------------------------
    selected, ranking = select_features(X, y)
    X_sel = X[selected]

    # 5/6) train + evaluate ------------------------------------------------
    X_train, X_test, y_train, y_test = train_test_split(
        X_sel, y, test_size=args.test_size, stratify=y, random_state=42)
    print(f"\n[split] train={len(X_train)} test={len(X_test)}")

    metrics, models = train_and_evaluate(X_train, X_test, y_train, y_test)

    # 7) summary -----------------------------------------------------------
    print("\n" + "=" * 70)
    print("FINAL MODEL COMPARISON (test set)")
    print("=" * 70)
    print(metrics.round(4).to_string())

    best_name = metrics["f1_score"].idxmax()
    print(f"\nBest model by F1-score: {best_name} "
          f"(F1={metrics.loc[best_name,'f1_score']:.4f}, "
          f"ROC-AUC={metrics.loc[best_name,'roc_auc']:.4f})")

    demo_predictions(models[best_name], selected)

    print("\nArtifacts:")
    print("  plots/   -> class_balance, feature_distributions, correlation_heatmap,")
    print("              boxplots, feature_importance, roc_curves, model_comparison,")
    print("              confusion_matrices")
    print("  results/ -> metrics.csv")


if __name__ == "__main__":
    main()
