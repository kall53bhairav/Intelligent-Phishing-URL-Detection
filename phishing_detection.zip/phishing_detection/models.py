"""
models.py
---------
Train and evaluate four classifiers for phishing URL detection:
  - Logistic Regression
  - Decision Tree
  - Random Forest
  - Support Vector Machine (RBF, probability enabled)

Evaluation metrics (on the held-out test set):
  - Precision, Recall, F1-score (for the phishing / positive class)
  - ROC-AUC
Also 5-fold cross-validated F1 on the training set.

Saves:
  - roc_curves.png          overlaid ROC curves for all models
  - model_comparison.png    grouped bar chart of the four metrics
  - confusion_matrices.png  confusion matrix per model
  - metrics.csv             raw metric table
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import (precision_score, recall_score, f1_score,
                             roc_auc_score, roc_curve, confusion_matrix,
                             classification_report)

PLOTS_DIR = "plots"
RESULTS_DIR = "results"


def build_models():
    """Return dict of named sklearn pipelines. Scaling matters for LR & SVM."""
    return {
        "Logistic Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=2000, random_state=42)),
        ]),
        "Decision Tree": Pipeline([
            ("clf", DecisionTreeClassifier(max_depth=12, random_state=42)),
        ]),
        "Random Forest": Pipeline([
            ("clf", RandomForestClassifier(n_estimators=300, random_state=42,
                                           n_jobs=-1)),
        ]),
        "SVM (RBF)": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", CalibratedClassifierCV(
                SVC(kernel="rbf", C=10, gamma="scale", random_state=42),
                ensemble=False, cv=3)),
        ]),
    }


def train_and_evaluate(X_train, X_test, y_train, y_test,
                       plots_dir=PLOTS_DIR, results_dir=RESULTS_DIR):
    os.makedirs(plots_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    models = build_models()
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    rows = []
    roc_data = {}
    conf_mats = {}

    for name, model in models.items():
        # cross-validated F1 on training data
        cv_f1 = cross_val_score(model, X_train, y_train, cv=cv,
                                scoring="f1", n_jobs=-1)

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        # probability / score for ROC-AUC
        if hasattr(model, "predict_proba"):
            y_score = model.predict_proba(X_test)[:, 1]
        else:
            y_score = model.decision_function(X_test)

        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_score)

        rows.append({
            "model": name,
            "precision": prec,
            "recall": rec,
            "f1_score": f1,
            "roc_auc": auc,
            "cv_f1_mean": cv_f1.mean(),
            "cv_f1_std": cv_f1.std(),
        })
        fpr, tpr, _ = roc_curve(y_test, y_score)
        roc_data[name] = (fpr, tpr, auc)
        conf_mats[name] = confusion_matrix(y_test, y_pred)

        print(f"\n----- {name} -----")
        print(classification_report(y_test, y_pred,
                                    target_names=["legit", "phishing"]))

    metrics = pd.DataFrame(rows).set_index("model")
    metrics.to_csv(os.path.join(results_dir, "metrics.csv"))

    # --- ROC curves -------------------------------------------------------
    plt.figure(figsize=(8, 7))
    for name, (fpr, tpr, auc) in roc_data.items():
        plt.plot(fpr, tpr, lw=2, label=f"{name} (AUC={auc:.3f})")
    plt.plot([0, 1], [0, 1], "k--", lw=1, label="Chance")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curves")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, "roc_curves.png"), dpi=120)
    plt.close()

    # --- metric comparison bar chart --------------------------------------
    plot_metrics = ["precision", "recall", "f1_score", "roc_auc"]
    ax = metrics[plot_metrics].plot(kind="bar", figsize=(11, 6),
                                    colormap="viridis", ylim=(0, 1.05))
    ax.set_title("Model Comparison")
    ax.set_ylabel("score")
    ax.set_xticklabels(metrics.index, rotation=15, ha="right")
    for c in ax.containers:
        ax.bar_label(c, fmt="%.3f", fontsize=7, padding=2)
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, "model_comparison.png"), dpi=120)
    plt.close()

    # --- confusion matrices ----------------------------------------------
    import seaborn as sns
    fig, axes = plt.subplots(1, 4, figsize=(20, 5))
    for ax, (name, cm) in zip(axes, conf_mats.items()):
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False,
                    xticklabels=["legit", "phish"],
                    yticklabels=["legit", "phish"], ax=ax)
        ax.set_title(name)
        ax.set_xlabel("predicted")
        ax.set_ylabel("actual")
    fig.suptitle("Confusion Matrices", fontsize=15)
    fig.tight_layout()
    fig.savefig(os.path.join(plots_dir, "confusion_matrices.png"), dpi=120)
    plt.close(fig)

    return metrics, models
