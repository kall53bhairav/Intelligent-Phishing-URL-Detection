"""
eda.py
------
Exploratory Data Analysis for the phishing feature set.

Produces and saves:
  - class_balance.png          bar chart of legit vs phishing counts
  - feature_distributions.png  histograms of key features split by class
  - correlation_heatmap.png    Pearson correlation matrix of features
  - boxplots.png               boxplots of discriminative features by class

Also prints summary statistics grouped by class.
"""
import os
import matplotlib
matplotlib.use("Agg")  # headless
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

from features import FEATURE_NAMES

PLOTS_DIR = "plots"


def run_eda(X: pd.DataFrame, y: pd.Series, plots_dir: str = PLOTS_DIR):
    os.makedirs(plots_dir, exist_ok=True)
    sns.set_theme(style="whitegrid")

    df = X.copy()
    df["label"] = y.values
    df["class"] = df["label"].map({0: "legit", 1: "phishing"})

    # 1) Class balance ------------------------------------------------------
    plt.figure(figsize=(5, 4))
    counts = df["class"].value_counts()
    sns.barplot(x=counts.index, y=counts.values, hue=counts.index,
                palette=["#2a9d8f", "#e76f51"], legend=False)
    plt.title("Class Balance")
    plt.ylabel("count")
    for i, v in enumerate(counts.values):
        plt.text(i, v + 20, str(v), ha="center")
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, "class_balance.png"), dpi=120)
    plt.close()

    # 2) Distributions of key features -------------------------------------
    key_feats = ["url_length", "num_dots", "digit_ratio", "url_entropy",
                 "num_subdomains", "special_ratio", "host_length", "num_keywords"]
    fig, axes = plt.subplots(2, 4, figsize=(20, 9))
    for ax, feat in zip(axes.ravel(), key_feats):
        for cls, color in [("legit", "#2a9d8f"), ("phishing", "#e76f51")]:
            sns.histplot(df[df["class"] == cls][feat], ax=ax, color=color,
                         label=cls, kde=True, stat="density", alpha=0.5, bins=30)
        ax.set_title(feat)
        ax.legend()
    fig.suptitle("Feature Distributions by Class", fontsize=16)
    fig.tight_layout()
    fig.savefig(os.path.join(plots_dir, "feature_distributions.png"), dpi=120)
    plt.close(fig)

    # 3) Correlation heatmap -----------------------------------------------
    plt.figure(figsize=(16, 13))
    corr = X[FEATURE_NAMES].corr()
    sns.heatmap(corr, cmap="coolwarm", center=0, square=True,
                linewidths=0.3, cbar_kws={"shrink": 0.7})
    plt.title("Feature Correlation Matrix (Pearson)")
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, "correlation_heatmap.png"), dpi=120)
    plt.close()

    # 4) Boxplots of discriminative features -------------------------------
    fig, axes = plt.subplots(2, 4, figsize=(20, 9))
    for ax, feat in zip(axes.ravel(), key_feats):
        sns.boxplot(data=df, x="class", y=feat, hue="class",
                    palette=["#2a9d8f", "#e76f51"], ax=ax, legend=False)
        ax.set_title(feat)
    fig.suptitle("Feature Boxplots by Class", fontsize=16)
    fig.tight_layout()
    fig.savefig(os.path.join(plots_dir, "boxplots.png"), dpi=120)
    plt.close(fig)

    # 5) Summary statistics -------------------------------------------------
    summary = df.groupby("class")[FEATURE_NAMES].mean().T
    summary["difference"] = (summary["phishing"] - summary["legit"]).abs()
    summary = summary.sort_values("difference", ascending=False)

    print("\n=== EDA: mean feature values by class (sorted by |difference|) ===")
    print(summary.round(3).to_string())
    print(f"\nSaved 4 plots to ./{plots_dir}/")

    return summary
