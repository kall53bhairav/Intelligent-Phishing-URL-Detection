"""
feature_selection.py
--------------------
Selects an informative, non-redundant feature subset using three signals:

  1. Correlation pruning   -> drop one of any pair with |corr| > 0.90
  2. Univariate ANOVA F    -> SelectKBest(f_classif) score per feature
  3. Random Forest gain    -> impurity-based importance per feature

Final ranking = average of the (min-max normalized) ANOVA and RF scores,
computed only over features surviving correlation pruning. Saves a bar chart
of importances.
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier

PLOTS_DIR = "plots"


def _minmax(s: pd.Series) -> pd.Series:
    rng = s.max() - s.min()
    return (s - s.min()) / rng if rng > 0 else s * 0.0


def select_features(X: pd.DataFrame, y: pd.Series,
                    corr_threshold: float = 0.90,
                    top_k: int | None = None,
                    plots_dir: str = PLOTS_DIR):
    os.makedirs(plots_dir, exist_ok=True)

    # --- 1) correlation pruning -------------------------------------------
    corr = X.corr().abs()
    upper = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool))
    to_drop = [col for col in upper.columns if any(upper[col] > corr_threshold)]
    kept = [c for c in X.columns if c not in to_drop]
    Xk = X[kept]

    # --- 2) univariate ANOVA F --------------------------------------------
    skb = SelectKBest(score_func=f_classif, k="all").fit(Xk, y)
    anova = pd.Series(skb.scores_, index=kept).fillna(0.0)

    # --- 3) random forest importance --------------------------------------
    rf = RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1)
    rf.fit(Xk, y)
    rf_imp = pd.Series(rf.feature_importances_, index=kept)

    # --- combine ----------------------------------------------------------
    ranking = pd.DataFrame({
        "anova_f": anova,
        "rf_importance": rf_imp,
        "anova_norm": _minmax(anova),
        "rf_norm": _minmax(rf_imp),
    })
    ranking["combined_score"] = (ranking["anova_norm"] + ranking["rf_norm"]) / 2
    ranking = ranking.sort_values("combined_score", ascending=False)

    if top_k is None:
        # keep features contributing to 95% of cumulative combined score
        cum = ranking["combined_score"].cumsum() / ranking["combined_score"].sum()
        top_k = int((cum <= 0.95).sum()) + 1
        top_k = max(top_k, 8)  # never fewer than 8
    selected = ranking.head(top_k).index.tolist()

    # --- plot -------------------------------------------------------------
    plt.figure(figsize=(10, 8))
    ranking["combined_score"].sort_values().plot(
        kind="barh", color="#264653")
    plt.title("Feature Importance (combined ANOVA-F + RF, normalized)")
    plt.xlabel("combined score")
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, "feature_importance.png"), dpi=120)
    plt.close()

    print("\n=== FEATURE SELECTION ===")
    if to_drop:
        print(f"Dropped {len(to_drop)} highly-correlated (>|{corr_threshold}|): {to_drop}")
    else:
        print(f"No feature pairs exceeded |corr| > {corr_threshold}")
    print(f"\nTop feature ranking:\n{ranking.round(4).to_string()}")
    print(f"\nSelected {len(selected)} features: {selected}")

    return selected, ranking
