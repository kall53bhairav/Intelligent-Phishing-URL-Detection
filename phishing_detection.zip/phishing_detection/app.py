"""
app.py
------
Streamlit UI for the Intelligent Phishing URL Detection System.

Run:
    ./venv/bin/streamlit run app.py

Reuses the exact feature-extraction, feature-selection and model-training
pipeline from the CLI project (features.py / feature_selection.py / models.py),
so the UI predictions match the trained models.

M.Tech Cyber Security, IIIT Sri City:
    Tushar Agarwal (OMCS25S00093)
    Sumit Parvat   (OMCS25S00088)
"""
import os
import time

import numpy as np
import pandas as pd
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score

from features import extract_features, featurize_frame, FEATURE_NAMES
from feature_selection import select_features
from models import build_models

DATA_PATH = "data/urls.csv"

# --------------------------------------------------------------------------- #
# Page config + minimal cosmetic CSS / animations
# --------------------------------------------------------------------------- #
st.set_page_config(
    page_title="Phishing URL Detector",
    page_icon="🛡️",
    layout="centered",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
    <style>
      /* ---- keyframes ---- */
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      @keyframes popIn {
        0%   { opacity: 0; transform: scale(0.85); }
        60%  { transform: scale(1.03); }
        100% { opacity: 1; transform: scale(1); }
      }
      @keyframes shimmer {
        0%   { background-position: -400px 0; }
        100% { background-position: 400px 0; }
      }
      @keyframes pulseDot {
        0%,100% { opacity: 1; }
        50%     { opacity: 0.25; }
      }
      @keyframes scanLineIn {
        from { opacity: 0; transform: translateX(-8px); }
        to   { opacity: 1; transform: translateX(0); }
      }

      .scanpanel {
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 0.9rem;
        line-height: 1.9;
        background: #0f172a;
        color: #e2e8f0;
        border-radius: 12px;
        padding: 1rem 1.2rem;
        border: 1px solid #1e293b;
        box-shadow: inset 0 0 24px rgba(42,157,143,0.10);
      }
      .scanpanel span { display: block; animation: scanLineIn 0.25s ease both; }
      .scan-live { color: #38bdf8; animation: pulseDot 0.9s ease-in-out infinite; }
      .scan-done { color: #4ade80; }

      .hero {
        animation: fadeInUp 0.7s ease both;
        text-align: center;
        padding: 1.4rem 1rem 0.6rem 1rem;
      }
      .hero h1 {
        margin: 0;
        font-size: 2.05rem;
        background: linear-gradient(90deg,#2a9d8f,#264653,#2a9d8f);
        background-size: 400px 100%;
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        animation: shimmer 6s linear infinite;
      }
      .hero p { margin: 0.35rem 0 0 0; color: #6b7280; font-size: 0.95rem; }

      .credits {
        text-align: center;
        font-size: 0.82rem;
        color: #8a94a6;
        margin-bottom: 0.5rem;
        animation: fadeInUp 0.9s ease both;
      }

      .verdict {
        border-radius: 16px;
        padding: 1.5rem 1.2rem;
        text-align: center;
        color: #fff;
        animation: popIn 0.55s cubic-bezier(.17,.67,.4,1.3) both;
        box-shadow: 0 8px 26px rgba(0,0,0,0.16);
      }
      .verdict.safe   { background: linear-gradient(135deg,#2a9d8f,#3ab795); }
      .verdict.danger { background: linear-gradient(135deg,#e63946,#d00000); }
      .verdict .big   { font-size: 2.0rem; font-weight: 800; letter-spacing: .5px; }
      .verdict .sub   { font-size: 1.0rem; opacity: .95; margin-top: .25rem; }

      .metric-card {
        animation: fadeInUp 0.8s ease both;
      }
      .stButton>button {
        border-radius: 10px;
        font-weight: 600;
        transition: transform .12s ease, box-shadow .12s ease;
      }
      .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(42,157,143,0.28);
      }
    </style>
    """,
    unsafe_allow_html=True,
)


# --------------------------------------------------------------------------- #
# Model training (cached so it runs once per session)
# --------------------------------------------------------------------------- #
@st.cache_resource(show_spinner=False)
def load_pipeline():
    """Load data, select features, train the best model, return artifacts."""
    if not os.path.exists(DATA_PATH):
        from generate_dataset import build_dataset
        os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
        build_dataset().to_csv(DATA_PATH, index=False)

    df = pd.read_csv(DATA_PATH)
    X = featurize_frame(df, url_col="url")
    y = df["label"].astype(int)

    selected, _ = select_features(X, y)
    X_sel = X[selected]

    X_train, X_test, y_train, y_test = train_test_split(
        X_sel, y, test_size=0.2, stratify=y, random_state=42
    )

    results = {}
    trained = {}
    for name, model in build_models().items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        if hasattr(model, "predict_proba"):
            y_score = model.predict_proba(X_test)[:, 1]
        else:
            y_score = model.decision_function(X_test)
        results[name] = {
            "precision": precision_score(y_test, y_pred),
            "recall": recall_score(y_test, y_pred),
            "f1_score": f1_score(y_test, y_pred),
            "roc_auc": roc_auc_score(y_test, y_score),
        }
        trained[name] = model

    metrics = pd.DataFrame(results).T
    best_name = metrics["f1_score"].idxmax()

    return {
        "selected": selected,
        "metrics": metrics,
        "best_name": best_name,
        "best_model": trained[best_name],
        "n_samples": len(df),
    }


def predict_url(model, feature_cols, url):
    feats = extract_features(url)
    X = pd.DataFrame([feats])[feature_cols]
    pred = int(model.predict(X)[0])
    try:
        prob = float(model.predict_proba(X)[0, 1])
    except AttributeError:
        prob = float("nan")
    return pred, prob, feats


# --------------------------------------------------------------------------- #
# Header
# --------------------------------------------------------------------------- #
st.markdown(
    """
    <div class="hero">
      <h1>🛡️ Intelligent Phishing URL Detector</h1>
      <p>Lexical · structural · host-based analysis with machine learning</p>
    </div>
    <div class="credits">
      M.Tech Cyber Security, IIIT Sri City<br/>
      <b>Tushar Agarwal (OMCS25S00093)</b> &nbsp;•&nbsp;
      <b>Sumit Parvat (OMCS25S00088)</b>
    </div>
    """,
    unsafe_allow_html=True,
)

with st.spinner("Training the detection model (first run only)…"):
    pipe = load_pipeline()

best_name = pipe["best_name"]
best_model = pipe["best_model"]
selected = pipe["selected"]
metrics = pipe["metrics"]

# --------------------------------------------------------------------------- #
# Input
# --------------------------------------------------------------------------- #
st.write("")
url = st.text_input(
    "Enter a URL to analyze",
    value="",
    placeholder="e.g. http://secure-appleid.verify-account.xyz/confirm?id=x9f2",
)

col_a, col_b = st.columns([1, 1])
with col_a:
    analyze = st.button("🔍 Analyze URL", use_container_width=True)
with col_b:
    if st.button("🎲 Try a sample phishing URL", use_container_width=True):
        url = "http://update-amazon.billing.login.tk/webscr?cmd=_signin"
        analyze = True

# --------------------------------------------------------------------------- #
# Result
# --------------------------------------------------------------------------- #
if analyze:
    if not url.strip():
        st.warning("Please enter a URL first.")
    else:
        # ---- genuine-feeling security scan animation ----------------------
        scan_steps = [
            "🔗 Parsing URL structure…",
            "🔤 Analyzing lexical characters & entropy…",
            "🌐 Inspecting host, TLD & subdomains…",
            "🚩 Matching phishing keyword lexicon…",
            "🔒 Checking HTTPS, IP-literal & redirects…",
            "🧠 Scoring with trained model…",
        ]

        scan_box = st.empty()
        prog = st.progress(0, text="Starting scan…")
        done_lines = []

        for i, step in enumerate(scan_steps):
            # show the current step as "in progress" with a pulsing dot
            live = "<br/>".join(done_lines + [
                f'<span class="scan-live">◉ {step}</span>'
            ])
            scan_box.markdown(
                f'<div class="scanpanel">{live}</div>', unsafe_allow_html=True
            )
            prog.progress(int((i + 1) / len(scan_steps) * 100),
                          text=f"Scanning… {int((i + 1) / len(scan_steps) * 100)}%")
            time.sleep(0.35)
            # mark the step as completed with a green check
            done_lines.append(f'<span class="scan-done">✓ {step}</span>')
            scan_box.markdown(
                f'<div class="scanpanel">{"<br/>".join(done_lines)}</div>',
                unsafe_allow_html=True,
            )

        time.sleep(0.25)
        scan_box.empty()
        prog.empty()

        pred, prob, feats = predict_url(best_model, selected, url)
        pct = 0.0 if np.isnan(prob) else prob * 100

        if pred == 1:
            st.markdown(
                f"""
                <div class="verdict danger">
                  <div class="big">⚠️ PHISHING</div>
                  <div class="sub">Estimated phishing probability: {pct:.1f}%</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f"""
                <div class="verdict safe">
                  <div class="big">✅ LEGITIMATE</div>
                  <div class="sub">Estimated phishing probability: {pct:.1f}%</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.balloons()

        st.write("")
        st.progress(int(pct), text=f"Phishing risk score: {pct:.1f}%")

        with st.expander("🔬 Why this verdict? (feature breakdown)"):
            signal_keys = [
                "url_length", "num_keywords", "suspicious_tld", "has_ip",
                "uses_https", "num_at", "num_digits", "host_length",
                "url_entropy", "num_subdomains",
            ]
            fb = pd.DataFrame(
                {"feature": signal_keys,
                 "value": [round(float(feats[k]), 3) for k in signal_keys]}
            )
            st.dataframe(fb, use_container_width=True, hide_index=True)
            st.caption(
                "Red flags: phishing keywords (secure/login/verify), suspicious "
                "TLDs (.tk .xyz .top), IP-literal hosts, '@' redirects, long URLs, "
                "and no HTTPS."
            )

# --------------------------------------------------------------------------- #
# Model info
# --------------------------------------------------------------------------- #
st.divider()
st.subheader(f"📊 Active model: {best_name}")

m = metrics.loc[best_name]
c1, c2, c3, c4 = st.columns(4)
c1.metric("Precision", f"{m['precision']:.3f}")
c2.metric("Recall", f"{m['recall']:.3f}")
c3.metric("F1-score", f"{m['f1_score']:.3f}")
c4.metric("ROC-AUC", f"{m['roc_auc']:.4f}")

with st.expander("Compare all four models"):
    st.dataframe(metrics.round(4), use_container_width=True)

st.caption(
    f"Trained on {pipe['n_samples']} URLs · {len(selected)} selected features · "
    "Models: Logistic Regression, Decision Tree, Random Forest, SVM (RBF)."
)
