# Intelligent Phishing URL Detection System

Predicts whether a URL is **legitimate** or **phishing** using lexical,
structural, and host-based characteristics. Trains and compares four classifiers
and evaluates them with Precision, Recall, F1-score, and ROC-AUC.

## Pipeline

```
generate_dataset.py -> features.py -> eda.py -> feature_selection.py -> models.py
                                     (orchestrated by main.py)
```

1. **Data** (`generate_dataset.py`) — builds a balanced, *realistic* dataset of
   5000 URLs (2500 legit / 2500 phishing). Includes deliberate class overlap:
   "hard" legit URLs that look suspicious (long paths, digits, query strings) and
   "stealth" phishing URLs that mimic clean HTTPS domains — so the task is not
   trivially separable. Replace with your own `[url,label]` CSV via `--data`.

2. **Features** (`features.py`) — extracts **28 features** in three families:
   - *Lexical / character-level*: url_length, num_dots, num_hyphens, num_at,
     num_question, num_equals, num_underscore, num_percent, num_ampersand,
     num_digits, num_special, digit_ratio, special_ratio, **url_entropy**
     (Shannon entropy).
   - *Structural*: num_subdomains, path_length, num_path_segments, query_length,
     num_query_params, has_port.
   - *Host-based / protocol*: uses_https, has_ip (IP-literal host),
     host_length, host_digit_ratio, tld_length, suspicious_tld, has_punycode
     (IDN homograph), num_keywords (phishing lexicon hits).

3. **EDA** (`eda.py`) — class balance, per-class feature distributions,
   correlation heatmap, boxplots, and a mean-difference table.

4. **Feature selection** (`feature_selection.py`) — correlation pruning
   (drop |corr| > 0.90), univariate ANOVA-F, and Random-Forest importance;
   combined normalized score picks the final subset.

5. **Models** (`models.py`) — Logistic Regression, Decision Tree, Random Forest,
   SVM (RBF, probability-calibrated). LR and SVM are scaled with StandardScaler.

6. **Evaluation** — Precision, Recall, F1, ROC-AUC on a stratified 20% test set,
   plus 5-fold cross-validated F1. Saves ROC curves, a metric comparison bar
   chart, and confusion matrices.

## Run

```bash
python3 -m venv venv
./venv/bin/pip install scikit-learn pandas numpy matplotlib seaborn streamlit
./venv/bin/python main.py                    # synthetic data (CLI pipeline)
./venv/bin/python main.py --data your.csv     # your own [url,label] csv
```

### Web UI (interactive)

A Streamlit app (`app.py`) lets you paste any URL and see a live
legit/phishing verdict with a probability score, a feature breakdown, and the
model metrics — with minimal animations.

```bash
./venv/bin/streamlit run app.py
```

Then open http://localhost:8501. The app trains the model once (cached) and
reuses the exact feature-extraction and modeling pipeline as the CLI.

> College project — Roll No OMCS25S00093 · Group member Sumit Parvat (OMCS25S00088)

## Outputs

- `plots/` — class_balance, feature_distributions, correlation_heatmap,
  boxplots, feature_importance, roc_curves, model_comparison, confusion_matrices
- `results/metrics.csv` — full metric table

## Latest results (test set, n=1000)

| Model               | Precision | Recall | F1     | ROC-AUC |
|---------------------|-----------|--------|--------|---------|
| Logistic Regression | 0.994     | 0.984  | 0.989  | 0.9996  |
| Decision Tree       | 0.996     | 0.990  | 0.993  | 0.9929  |
| Random Forest       | 0.994     | 0.994  | 0.994  | 0.9994  |
| SVM (RBF)           | 0.986     | 0.990  | 0.988  | 0.9996  |

Best model by F1: **Random Forest** (F1 = 0.994, ROC-AUC = 0.9994).

> Note: metrics are strong because the dataset is synthetic. On real-world
> corpora (PhishTank, OpenPhish, UCI) expect lower but still competitive numbers.
> The feature extractor and modeling code work unchanged on real `[url,label]` data.
