"""
features.py
-----------
Feature engineering for phishing URL detection.

Extracts lexical, structural and host-based characteristics from a raw URL:

  Lexical / character-level:
    - url_length            total length of the URL
    - num_dots              count of '.'
    - num_hyphens           count of '-'
    - num_at                count of '@'   (redirect trick)
    - num_question          count of '?'
    - num_equals            count of '='
    - num_underscore        count of '_'
    - num_percent           count of '%'   (encoding)
    - num_ampersand         count of '&'
    - num_digits            count of digit chars
    - num_special           count of non-alphanumeric chars
    - digit_ratio           digits / length
    - special_ratio         special chars / length
    - url_entropy           Shannon entropy of the whole URL string

  Structural:
    - num_subdomains        number of subdomains in the host
    - path_length           length of the path component
    - num_path_segments     number of '/'-separated path segments
    - query_length          length of the query string
    - num_query_params      number of query parameters
    - has_port              1 if an explicit port is present

  Host-based / protocol:
    - uses_https            1 if scheme is https
    - has_ip                1 if the host is an IP literal
    - host_length           length of the host
    - host_digit_ratio      digit ratio within the host
    - tld_length            length of the top-level domain
    - suspicious_tld        1 if TLD in a known-abused set
    - has_punycode          1 if 'xn--' present (IDN homograph)
    - num_keywords          count of phishing keyword hits (secure, login, ...)
"""
import math
import re
from urllib.parse import urlparse

SUSPICIOUS_TLDS = {"tk", "ml", "ga", "cf", "gq", "xyz", "top", "click",
                   "info", "zip", "work", "party", "review", "country"}

PHISH_KEYWORDS = {"secure", "verify", "account", "update", "login", "signin",
                  "confirm", "webscr", "banking", "bank", "alert", "suspended",
                  "billing", "recover", "unlock", "validation", "password", "pay"}

IP_RE = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")

FEATURE_NAMES = [
    "url_length", "num_dots", "num_hyphens", "num_at", "num_question",
    "num_equals", "num_underscore", "num_percent", "num_ampersand",
    "num_digits", "num_special", "digit_ratio", "special_ratio", "url_entropy",
    "num_subdomains", "path_length", "num_path_segments", "query_length",
    "num_query_params", "has_port",
    "uses_https", "has_ip", "host_length", "host_digit_ratio", "tld_length",
    "suspicious_tld", "has_punycode", "num_keywords",
]


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def _split_host(netloc: str):
    """Return (host, port) stripping any userinfo before '@'."""
    if "@" in netloc:
        netloc = netloc.split("@")[-1]  # take the part after '@' (the real host)
    port = None
    if ":" in netloc:
        host, _, maybe_port = netloc.rpartition(":")
        if maybe_port.isdigit():
            port = maybe_port
            netloc = host
    return netloc, port


def extract_features(url: str) -> dict:
    url = str(url).strip()

    # Ensure urlparse sees a scheme; if missing, treat as http for parsing.
    parse_target = url if "://" in url else "http://" + url
    parsed = urlparse(parse_target)

    scheme = parsed.scheme.lower()
    raw_netloc = parsed.netloc
    host, port = _split_host(raw_netloc)
    path = parsed.path or ""
    query = parsed.query or ""

    length = len(url) if url else 1
    digits = sum(c.isdigit() for c in url)
    specials = sum((not c.isalnum()) for c in url)

    # host / domain analysis
    has_ip = 1 if IP_RE.match(host) else 0
    host_digits = sum(c.isdigit() for c in host)
    labels = host.split(".") if host else []
    tld = labels[-1].lower() if len(labels) >= 1 and not has_ip else ""
    # subdomains = labels minus the registrable domain (domain + tld).
    if has_ip or len(labels) <= 2:
        num_subdomains = 0
    else:
        num_subdomains = len(labels) - 2

    lower_url = url.lower()
    num_keywords = sum(1 for kw in PHISH_KEYWORDS if kw in lower_url)

    query_params = [p for p in query.split("&") if p] if query else []
    path_segments = [p for p in path.split("/") if p]

    return {
        "url_length": length,
        "num_dots": url.count("."),
        "num_hyphens": url.count("-"),
        "num_at": url.count("@"),
        "num_question": url.count("?"),
        "num_equals": url.count("="),
        "num_underscore": url.count("_"),
        "num_percent": url.count("%"),
        "num_ampersand": url.count("&"),
        "num_digits": digits,
        "num_special": specials,
        "digit_ratio": digits / length,
        "special_ratio": specials / length,
        "url_entropy": shannon_entropy(url),
        "num_subdomains": num_subdomains,
        "path_length": len(path),
        "num_path_segments": len(path_segments),
        "query_length": len(query),
        "num_query_params": len(query_params),
        "has_port": 1 if port else 0,
        "uses_https": 1 if scheme == "https" else 0,
        "has_ip": has_ip,
        "host_length": len(host),
        "host_digit_ratio": (host_digits / len(host)) if host else 0.0,
        "tld_length": len(tld),
        "suspicious_tld": 1 if tld in SUSPICIOUS_TLDS else 0,
        "has_punycode": 1 if "xn--" in lower_url else 0,
        "num_keywords": num_keywords,
    }


def featurize_frame(df, url_col="url"):
    """Return a DataFrame of features aligned to df[url_col]."""
    import pandas as pd
    feats = [extract_features(u) for u in df[url_col]]
    return pd.DataFrame(feats, columns=FEATURE_NAMES)


if __name__ == "__main__":
    tests = [
        "https://www.google.com/search?q=news",
        "http://paypal.com@192.168.0.5/secure/login?id=abc123",
        "http://secure-apple.verify.xyz/confirm?id=zz",
    ]
    for t in tests:
        print(t)
        for k, v in extract_features(t).items():
            print(f"   {k:20s} {v}")
        print()
