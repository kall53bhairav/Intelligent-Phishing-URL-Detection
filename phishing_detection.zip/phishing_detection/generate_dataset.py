"""
generate_dataset.py
-------------------
Builds a labeled dataset of URLs (legitimate vs phishing).

Real-world phishing corpora (PhishTank, OpenPhish, UCI, Mendeley) require network
access / registration. To keep this project fully reproducible offline, we
synthesize a realistic dataset whose statistical properties mirror the patterns
documented in the phishing-detection literature:

  * Legitimate URLs   -> short, few dots, https, recognizable brand domains,
                         clean paths, few special chars, low entropy.
  * Phishing URLs      -> long, many subdomains/dots, IP-literals, '@' redirects,
                         hyphens & digits in host, brand names as subdomains of
                         random hosts, suspicious TLDs, high entropy, punycode.

If you have a real CSV with columns [url, label] you can skip this file and
point the pipeline at it instead.
"""
import random
import string
import pandas as pd

RNG = random.Random(42)

LEGIT_DOMAINS = [
    "google.com", "youtube.com", "facebook.com", "wikipedia.org", "amazon.com",
    "twitter.com", "instagram.com", "linkedin.com", "netflix.com", "microsoft.com",
    "apple.com", "github.com", "stackoverflow.com", "reddit.com", "paypal.com",
    "dropbox.com", "adobe.com", "spotify.com", "cnn.com", "bbc.co.uk",
    "nytimes.com", "yahoo.com", "ebay.com", "wordpress.org", "mozilla.org",
    "cloudflare.com", "office.com", "zoom.us", "slack.com", "gitlab.com",
]

LEGIT_PATHS = [
    "", "/", "/about", "/contact", "/products", "/help/faq", "/search?q=news",
    "/user/profile", "/blog/2024/best-practices", "/docs/getting-started",
    "/account/settings", "/watch?v=abcd1234", "/login", "/pricing", "/careers",
]

BRANDS = ["paypal", "apple", "microsoft", "amazon", "netflix", "google",
          "facebook", "bankofamerica", "wellsfargo", "chase", "dhl", "fedex"]

SUSPICIOUS_TLDS = ["tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "info", "zip"]

PHISH_KEYWORDS = ["secure", "verify", "account", "update", "login", "signin",
                  "confirm", "webscr", "banking", "alert", "suspended", "billing",
                  "recover", "unlock", "validation"]


def _rand_str(n):
    return "".join(RNG.choice(string.ascii_lowercase + string.digits) for _ in range(n))


def _rand_ip():
    return ".".join(str(RNG.randint(1, 254)) for _ in range(4))


def make_legit():
    domain = RNG.choice(LEGIT_DOMAINS)
    scheme = "https" if RNG.random() < 0.9 else "http"
    # occasional benign subdomain
    if RNG.random() < 0.25:
        domain = RNG.choice(["www", "mail", "docs", "app", "shop"]) + "." + domain
    path = RNG.choice(LEGIT_PATHS)
    return f"{scheme}://{domain}{path}"


def make_phish():
    scheme = "http" if RNG.random() < 0.7 else "https"
    style = RNG.random()

    if style < 0.2:
        # IP-literal host
        host = _rand_ip()
        path = "/" + RNG.choice(PHISH_KEYWORDS) + "/" + _rand_str(RNG.randint(6, 14))
        return f"{scheme}://{host}{path}"

    if style < 0.4:
        # brand as subdomain of random junk host (+ suspicious tld)
        brand = RNG.choice(BRANDS)
        junk = _rand_str(RNG.randint(6, 12))
        tld = RNG.choice(SUSPICIOUS_TLDS)
        host = f"{brand}-{RNG.choice(PHISH_KEYWORDS)}.{junk}.{tld}"
        path = "/" + RNG.choice(PHISH_KEYWORDS) + "?id=" + _rand_str(RNG.randint(8, 20))
        return f"{scheme}://{host}{path}"

    if style < 0.6:
        # '@' redirect trick + long host
        brand = RNG.choice(BRANDS)
        real = _rand_str(RNG.randint(8, 15))
        tld = RNG.choice(SUSPICIOUS_TLDS)
        return (f"{scheme}://{brand}.com@{real}.{tld}/"
                f"{RNG.choice(PHISH_KEYWORDS)}/{_rand_str(RNG.randint(6, 12))}")

    if style < 0.8:
        # many subdomains + hyphens + digits
        parts = [RNG.choice(PHISH_KEYWORDS), RNG.choice(BRANDS), _rand_str(4),
                 _rand_str(RNG.randint(6, 10))]
        RNG.shuffle(parts)
        host = "-".join(parts[:2]) + "." + ".".join(parts[2:]) + "." + RNG.choice(SUSPICIOUS_TLDS)
        path = "/" + "/".join(RNG.choice(PHISH_KEYWORDS) for _ in range(RNG.randint(1, 3)))
        path += "-" + _rand_str(RNG.randint(10, 25))
        return f"{scheme}://{host}{path}"

    # very long query-string laden URL
    brand = RNG.choice(BRANDS)
    host = f"{brand}{RNG.randint(10,999)}.{_rand_str(8)}.{RNG.choice(SUSPICIOUS_TLDS)}"
    query = "&".join(f"{_rand_str(3)}={_rand_str(RNG.randint(4,10))}"
                     for _ in range(RNG.randint(3, 6)))
    return f"{scheme}://{host}/{RNG.choice(PHISH_KEYWORDS)}/webscr?cmd=_{_rand_str(6)}&{query}"


def make_legit_hard():
    """Legit URL that superficially looks suspicious (long path, digits, query).
    Introduces class overlap so the problem isn't trivially separable."""
    domain = RNG.choice(LEGIT_DOMAINS)
    scheme = "https" if RNG.random() < 0.6 else "http"  # some legit http
    sub = RNG.choice(["www", "shop", "login", "secure", "account", "my"])
    domain = f"{sub}.{domain}"
    seg = RNG.choice(["order", "product", "item", "user", "session", "checkout"])
    path = f"/{seg}/{RNG.randint(100000, 9999999)}"
    query = f"?ref={_rand_str(6)}&sid={RNG.randint(1000,99999)}"
    return f"{scheme}://{domain}{path}{query}"


def make_phish_stealth():
    """Phishing URL that mimics clean legit style (short, https, few specials).
    Uses a plausible-looking but bogus domain."""
    brand = RNG.choice(BRANDS)
    variant = RNG.choice([f"{brand}-support", f"{brand}secure", f"my{brand}",
                          f"{brand}account", f"{brand}-help"])
    tld = RNG.choice(["com", "net", "org", "co"])  # non-suspicious tld
    scheme = "https"  # stealth phishing increasingly uses https
    path = RNG.choice(["/login", "/signin", "/account", "/", "/verify"])
    return f"{scheme}://{variant}.{tld}{path}"


def build_dataset(n_legit=2500, n_phish=2500, seed=42,
                  hard_legit_frac=0.18, stealth_phish_frac=0.18):
    global RNG
    RNG = random.Random(seed)
    rows = []
    seen = set()

    def add(url, label):
        if url not in seen:
            seen.add(url)
            rows.append({"url": url, "label": label})

    n_hard_legit = int(n_legit * hard_legit_frac)
    n_stealth = int(n_phish * stealth_phish_frac)

    # legit: mix of clean and "hard" (suspicious-looking) legit URLs
    tries = 0
    while sum(1 for r in rows if r["label"] == 0) < n_legit and tries < n_legit * 40:
        made_hard = sum(1 for r in rows if r["label"] == 0) < n_hard_legit
        add(make_legit_hard() if made_hard else make_legit(), 0)
        tries += 1
    # phishing: mix of obvious and stealthy phishing URLs
    tries = 0
    while sum(1 for r in rows if r["label"] == 1) < n_phish and tries < n_phish * 40:
        made_stealth = sum(1 for r in rows if r["label"] == 1) < n_stealth
        add(make_phish_stealth() if made_stealth else make_phish(), 1)
        tries += 1

    df = pd.DataFrame(rows).sample(frac=1, random_state=seed).reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = build_dataset()
    out = "data/urls.csv"
    import os
    os.makedirs("data", exist_ok=True)
    df.to_csv(out, index=False)
    print(f"Wrote {len(df)} rows to {out}")
    print(df["label"].value_counts().rename({0: "legit", 1: "phishing"}))
    print(df.head(10).to_string())
