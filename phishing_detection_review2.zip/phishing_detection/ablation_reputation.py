"""
ablation_reputation.py
----------------------
How much do the two reputation features (domain_popularity, free_hosting) add?
Retrains the handcrafted models with and without them on the same split and
reports test metrics plus the real-world sanity checks.

    python ablation_reputation.py   ->  results/r2_ablation_reputation.csv
"""
import json

import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler

from dl_models import FeatureMLP, predict_proba, train_model
from run_review2 import REP_FEATURES, SEED, hc_matrix
from url_utils import hostname

df = pd.read_csv("data/real_urls.csv")
tr, va, te = (df[df.split == s].reset_index(drop=True) for s in ("train", "val", "test"))
sel = json.load(open("models/meta.json"))["selected_features"]
legit = [l.strip() for l in open("data/sanity/familiar_legit_urls.txt") if l.strip()]
feed = pd.DataFrame({"u": [l.strip() for l in open("data/sanity/openphish_2026-11-13.txt") if l.strip()]})
feed["h"] = feed.u.map(hostname)
feed = feed[~feed.h.isin(set(df.host))].drop_duplicates("h")
from url_utils import canonicalize
X = {k: hc_matrix(d) for k, d in [("tr", tr.url), ("va", va.url), ("te", te.url),
                                   ("fam", [canonicalize(u) for u in legit]),
                                   ("live", [canonicalize(u) for u in feed.u])]}
rows = []
for tag, cols in [("with reputation", sel), ("lexical only", [c for c in sel if c not in REP_FEATURES])]:
    gb = HistGradientBoostingClassifier(max_iter=400, learning_rate=0.08, max_leaf_nodes=63, random_state=SEED)
    gb.fit(X["tr"][cols], tr.label)
    sc = StandardScaler().fit(X["tr"][cols])
    z = lambda k: np.clip(sc.transform(X[k][cols]), -6, 6).astype(np.float32)
    torch.manual_seed(SEED)
    mlp, _ = train_model(FeatureMLP(n_feats=len(cols)), {"chars": None, "feats": z("tr"), "y": tr.label.values},
                         {"chars": None, "feats": z("va"), "y": va.label.values}, epochs=20, lr=1e-3, log=lambda s: None)
    for name, P in [("Gradient Boosting", lambda k: gb.predict_proba(X[k][cols])[:, 1]),
                    ("MLP", lambda k: predict_proba(mlp, None, z(k)))]:
        p = P("te")
        rows.append({"model": name, "features": tag, "n_features": len(cols), "f1": f1_score(te.label, p >= .5),
                     "roc_auc": roc_auc_score(te.label, p), "familiar_false_alarms": int((P("fam") >= .5).sum()),
                     "familiar_n": len(legit), "live_detect": float((P("live") >= .5).mean())})
res = pd.DataFrame(rows)
res.to_csv("results/r2_ablation_reputation.csv", index=False)
print(res.round(4).to_string(index=False))
