"""
app.py  (Review 2)
------------------
Streamlit interface: a user enters a URL and gets a phishing-risk prediction.

  * choose the model (handcrafted ML, MLP, char-CNN, char-BiLSTM, hybrid)
  * choose the operating point (balanced 0.5  or  low false-alarm <=1% FPR)
  * risk score 0-100 + LOW / MEDIUM / HIGH band + verdict
  * WHY: character-level saliency heat-map (learned models) + rule red flags
  * all models side-by-side (handcrafted ML vs learned DL agreement)
  * batch scan of many URLs / CSV upload with downloadable results
  * benchmark tab with the Review-2 test metrics

Run:
    streamlit run app.py
Models are loaded from models/ (created by run_review2.py) -- no retraining.

M.Tech Cyber Security, IIIT Sri City:
    Tushar Agarwal (OMCS25S00093)  |  Sumit Parvat (OMCS25S00088)
"""
import os
import time

import pandas as pd
import streamlit as st

st.set_page_config(page_title="Phishing URL Risk Predictor", page_icon="🛡️",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@keyframes fadeInUp {from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:none}}
@keyframes popIn {0%{opacity:0;transform:scale(.9)} 70%{transform:scale(1.02)} 100%{opacity:1;transform:scale(1)}}
@keyframes scanLineIn {from{opacity:0;transform:translateX(-8px)} to{opacity:1;transform:none}}
@keyframes pulseDot {0%,100%{opacity:1} 50%{opacity:.3}}
.hero{animation:fadeInUp .6s ease both;padding:.4rem 0 .2rem 0}
.hero h1{margin:0;font-size:2.0rem;color:#0F1B2D}
.hero p{margin:.2rem 0 0 0;color:#64748b}
.credits{font-size:.82rem;color:#8a94a6;margin-bottom:.6rem}
.verdict{border-radius:16px;padding:1.3rem 1.2rem;color:#fff;animation:popIn .5s ease both;
         box-shadow:0 8px 24px rgba(15,27,45,.18)}
.verdict.safe{background:linear-gradient(135deg,#2a9d8f,#3ab795)}
.verdict.warn{background:linear-gradient(135deg,#e9a23b,#f4a261)}
.verdict.danger{background:linear-gradient(135deg,#e63946,#c1121f)}
.verdict .big{font-size:1.9rem;font-weight:800;letter-spacing:.5px}
.verdict .sub{font-size:1rem;opacity:.95;margin-top:.2rem}
.gauge{position:relative;height:22px;border-radius:11px;margin:.6rem 0 .2rem 0;
       background:linear-gradient(90deg,#2a9d8f 0%,#2a9d8f 30%,#e9a23b 30%,#e9a23b 70%,#e63946 70%,#e63946 100%)}
.gauge .needle{position:absolute;top:-6px;width:4px;height:34px;background:#0F1B2D;border-radius:2px}
.gauge-l{display:flex;justify-content:space-between;font-size:.78rem;color:#64748b}
.chip{display:inline-block;padding:.28rem .7rem;margin:.18rem .25rem .18rem 0;border-radius:999px;
      font-size:.85rem;animation:fadeInUp .4s ease both}
.chip.high{background:#fde2e4;color:#9d0208;border:1px solid #f5a3a9}
.chip.medium{background:#fff1d6;color:#8a5a00;border:1px solid #f3cf8a}
.chip.info{background:#eef2f7;color:#334155;border:1px solid #d5dde8}
.chip.good{background:#e3f4f1;color:#1b6f66;border:1px solid #9fd6cc}
.scanpanel{font-family:ui-monospace,Menlo,monospace;font-size:.88rem;line-height:1.85;background:#0f172a;
           color:#e2e8f0;border-radius:12px;padding:.9rem 1.1rem}
.scanpanel span{display:block;animation:scanLineIn .25s ease both}
.scan-live{color:#38bdf8;animation:pulseDot .9s ease-in-out infinite}
.scan-done{color:#4ade80}
.canon{font-family:ui-monospace,Menlo,monospace;background:#f1f5f9;border-radius:8px;padding:.35rem .6rem;
       font-size:.88rem;color:#0F1B2D;word-break:break-all}
.legend span{display:inline-block;width:12px;height:12px;border-radius:3px;margin:0 4px -1px 10px}
</style>
""", unsafe_allow_html=True)

MODEL_DIR = "models"
if not os.path.exists(os.path.join(MODEL_DIR, "meta.json")):
    st.error("Trained models not found. Run:\n\n"
             "`python prepare_real_data.py`  then  `python run_review2.py`")
    st.stop()

from explain import saliency_html                       # noqa: E402
from predictor import FAMILY, PhishPredictor, risk_band  # noqa: E402


@st.cache_resource(show_spinner=False)
def get_predictor():
    return PhishPredictor(MODEL_DIR)


with st.spinner("Loading trained models…"):
    pp = get_predictor()

SAMPLES = {
    "phish": "http://secure-update-account.paypa1-verify.com/signin/confirm",
    "phish2": "metamask-wallet-recovery.web.app",
    "legit": "https://www.github.com/features/actions",
}

# --------------------------------------------------------------------------- #
# Sidebar
# --------------------------------------------------------------------------- #
with st.sidebar:
    st.markdown("### ⚙️ Detection settings")
    model = st.selectbox("Model", pp.names, index=0)
    st.caption(f"Family: **{FAMILY[model]}**")
    mode = st.radio("Operating point", ["Balanced", "Low false-alarm"],
                    captions=["threshold 0.50",
                              "threshold tuned for ≤1% false-positive rate"])
    thr = pp.threshold(model, "low_fpr" if mode == "Low false-alarm" else "balanced")
    st.markdown(f"**Decision threshold:** `{thr:.3f}`")
    m = pp.meta["test_metrics"].get(model, {})
    if m:
        st.markdown("**Held-out test performance** (threshold 0.5)")
        a, b = st.columns(2)
        a.metric("Precision", f"{m['precision']:.3f}")
        b.metric("Recall", f"{m['recall']:.3f}")
        a.metric("F1", f"{m['f1']:.3f}")
        b.metric("ROC-AUC", f"{m['roc_auc']:.3f}")
        a.metric("FPR", f"{m['fpr']:.3f}")
        b.metric("FNR", f"{m['fnr']:.3f}")
    st.caption(f"Trained on {pp.meta.get('n_train', 0):,} real URLs (PhiUSIIL, Phishing.Database, Kaggle, CrUX), "
               "hostname-disjoint split. Scheme and 'www.' are removed before scoring.")

# --------------------------------------------------------------------------- #
# Header
# --------------------------------------------------------------------------- #
st.markdown("""
<div class="hero"><h1>🛡️ Phishing URL Risk Predictor</h1>
<p>Handcrafted-feature ML · character-level deep learning · hybrid model — Review 2</p></div>
<div class="credits">M.Tech Cyber Security, IIIT Sri City · <b>Tushar Agarwal (OMCS25S00093)</b>
 · <b>Sumit Parvat (OMCS25S00088)</b></div>
""", unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(["🔍 Analyze a URL", "📋 Batch scan", "📊 ML vs DL benchmark"])


def _set_sample(key):
    st.session_state["url_in"] = SAMPLES[key]
    st.session_state["go"] = True


# --------------------------------------------------------------------------- #
# Tab 1: single URL
# --------------------------------------------------------------------------- #
with tab1:
    url = st.text_input("Enter a URL to analyze", key="url_in",
                        placeholder="e.g. http://secure-login.example-verify.xyz/account")
    c1, c2, c3, c4 = st.columns([1.1, 1, 1, 1])
    go = c1.button("🔍 Analyze URL", type="primary", width="stretch")
    c2.button("🎣 Sample phishing", on_click=_set_sample, args=("phish",), width="stretch")
    c3.button("☁️ Free-hosting phish", on_click=_set_sample, args=("phish2",), width="stretch")
    c4.button("✅ Sample legitimate", on_click=_set_sample, args=("legit",), width="stretch")
    go = go or st.session_state.pop("go", False)

    if go:
        if not url.strip():
            st.warning("Please enter a URL first.")
        else:
            steps = ["Canonicalising URL (scheme, www, host case)…",
                     "Extracting 29 handcrafted lexical / host / reputation features…",
                     "Encoding characters for CNN / BiLSTM…",
                     f"Scoring with {len(pp.names)} trained models…",
                     "Computing character-level evidence…"]
            box, done = st.empty(), []
            for s in steps:
                box.markdown('<div class="scanpanel">' + "".join(
                    done + [f'<span class="scan-live">◉ {s}</span>']) + "</div>",
                    unsafe_allow_html=True)
                time.sleep(0.18)
                done.append(f'<span class="scan-done">✓ {s}</span>')
            box.empty()

            res = pp.predict_all([url]).iloc[0]
            p = float(res[model])
            band = risk_band(p)
            is_phish = p >= thr
            cls = "danger" if is_phish else ("warn" if band == "MEDIUM" else "safe")
            word = "⚠️ PHISHING" if is_phish else ("🟠 SUSPICIOUS" if band == "MEDIUM" else "✅ LEGITIMATE")

            left, right = st.columns([1, 1.25])
            with left:
                st.markdown(f"""<div class="verdict {cls}"><div class="big">{word}</div>
                <div class="sub">Risk score <b>{p*100:.1f} / 100</b> · {band} risk ·
                model: {model}</div></div>""", unsafe_allow_html=True)
            with right:
                st.markdown(f"""<div class="gauge"><div class="needle" style="left:calc({p*100:.1f}% - 2px)"></div></div>
                <div class="gauge-l"><span>0 · LOW</span><span>30</span><span>MEDIUM</span><span>70</span><span>HIGH · 100</span></div>""",
                            unsafe_allow_html=True)
                st.markdown(f'Model input (canonical form): <div class="canon">{res["canonical"]}</div>',
                            unsafe_allow_html=True)
                st.caption(f"Verdict uses threshold {thr:.3f} ({mode.lower()} operating point).")

            st.write("")
            ev, fl = st.columns([1.35, 1])
            with ev:
                st.markdown("##### 🧠 Character-level evidence")
                sal = pp.saliency(url, model)
                if sal is None:
                    sal = pp.saliency(url, "Char-CNN")
                    st.caption(f"{model} uses handcrafted features only — showing the Char-CNN view.")
                canon, base, scores = sal
                st.markdown(saliency_html(canon, scores), unsafe_allow_html=True)
                st.markdown('<div class="legend" style="font-size:.8rem;color:#64748b">'
                            '<span style="background:#e63946"></span>pushes towards phishing'
                            '<span style="background:#2a9d8f"></span>pushes towards legitimate'
                            ' · occlusion of 3-char windows</div>', unsafe_allow_html=True)
            with fl:
                st.markdown("##### 🚩 Rule-based signals")
                chips = "".join(f'<span class="chip {sev}"><b>{name}</b> — {det}</span>'
                                for name, det, sev in pp.flags(url))
                st.markdown(chips, unsafe_allow_html=True)

            st.write("")
            st.markdown("##### 🤝 Do handcrafted ML and learned DL agree?")
            rows = []
            for n in pp.names:
                pn = float(res[n])
                t = pp.threshold(n, "low_fpr" if mode == "Low false-alarm" else "balanced")
                rows.append({"Model": n, "Family": FAMILY[n], "P(phishing)": pn,
                             "Verdict": "PHISHING" if pn >= t else "legitimate"})
            agree = pd.DataFrame(rows)
            st.dataframe(agree, hide_index=True, width="stretch", column_config={
                "P(phishing)": st.column_config.ProgressColumn(
                    "P(phishing)", min_value=0.0, max_value=1.0, format="%.3f")})
            k = (agree.Verdict == "PHISHING").sum()
            st.caption(f"{k} of {len(agree)} models flag this URL as phishing.")

# --------------------------------------------------------------------------- #
# Tab 2: batch
# --------------------------------------------------------------------------- #
with tab2:
    st.markdown("Paste one URL per line **or** upload a CSV with a `url` column.")
    txt = st.text_area("URLs", height=150, placeholder="paypal.com/signin\nhttp://198.51.100.7/login.php\n…")
    up = st.file_uploader("…or upload CSV", type=["csv"])
    if st.button("Scan all", type="primary"):
        urls = [u.strip() for u in txt.splitlines() if u.strip()]
        if up is not None:
            dfu = pd.read_csv(up)
            if "url" in dfu.columns:
                urls += dfu["url"].astype(str).tolist()
            else:
                st.error("CSV needs a 'url' column.")
        if not urls:
            st.warning("No URLs given.")
        else:
            with st.spinner(f"Scoring {len(urls)} URLs…"):
                out = pp.predict_all(urls[:5000])
            out["risk_band"] = out[model].map(risk_band)
            out["verdict"] = (out[model] >= thr).map({True: "PHISHING", False: "legitimate"})
            show = out[["url", "verdict", "risk_band", model] +
                       [n for n in pp.names if n != model]]
            st.dataframe(show, hide_index=True, width="stretch", column_config={
                n: st.column_config.NumberColumn(format="%.3f") for n in pp.names})
            a, b, c = st.columns(3)
            a.metric("URLs scanned", len(out))
            b.metric("Flagged phishing", int((out.verdict == "PHISHING").sum()))
            c.metric("High-risk band", int((out.risk_band == "HIGH").sum()))
            st.download_button("⬇️ Download results CSV", out.to_csv(index=False),
                               "phishing_scan_results.csv", "text/csv")

# --------------------------------------------------------------------------- #
# Tab 3: benchmark
# --------------------------------------------------------------------------- #
with tab3:
    path = "results/r2_metrics.csv"
    if os.path.exists(path):
        met = pd.read_csv(path)
        cols = ["model", "family", "precision", "recall", "f1", "roc_auc", "pr_auc",
                "fpr", "fnr", "recall_at_1pct_fpr", "latency_ms"]
        st.markdown(f"#### Held-out test set ({pp.meta.get('n_test', 0):,} URLs, unseen hostnames)")
        st.dataframe(met[cols].sort_values("f1", ascending=False).round(4),
                     hide_index=True, width="stretch")
    for img, cap in [("plots/r2/roc_pr_curves.png", "ROC and precision-recall curves"),
                     ("plots/r2/threshold_tradeoff.png", "False-positive / false-negative trade-off")]:
        if os.path.exists(img):
            st.image(img, caption=cap)
