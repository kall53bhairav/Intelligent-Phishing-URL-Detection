"""
run_review2.py
--------------
Review 2 experiment:  handcrafted-feature ML  vs  learned-representation DL.

Every model is trained on the SAME hostname-disjoint train split, tuned/early-
stopped on the SAME validation split and scored on the SAME held-out test split.

  Handcrafted features + classic ML : LogReg, Decision Tree, Random Forest,
                                      SVM (RBF), Gradient Boosting (HGB)
  Handcrafted features + DL         : MLP
  Learned representation + DL       : char-CNN, char-BiLSTM
  Hybrid (learned + handcrafted)    : char-CNN + feature branch
  Reference (shallow learned)       : char n-gram TF-IDF + LogReg

Outputs
  results/r2_metrics.csv            one row per model (P, R, F1, AUC, PR-AUC,
                                    FPR, FNR, recall@1%FPR, latency, size, ...)
  results/r2_test_predictions.csv   per-URL test probabilities of every model
  results/r2_val_predictions.csv    same on validation (threshold tuning)
  results/r2_dl_history.json        epoch curves for the DL models
  results/r2_significance.csv       McNemar tests between model pairs
  models/                           fitted artefacts used by the web interface

Usage
  python prepare_real_data.py               # once: builds data/real_urls.csv
  python run_review2.py                     # real-world benchmark (default)
  python run_review2.py --data data/urls.csv --tag synthetic   # Review-1 data
"""
import argparse
import io
import json
import os
import time

import joblib
import numpy as np
import pandas as pd
import torch
from scipy.stats import chi2
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score,
                             confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from dl_models import (CharBiLSTM, CharCNN, FeatureMLP, HybridCNN, USES_CHARS,
                       USES_FEATS, n_params, predict_proba, save_dl, train_model)
from feature_selection import select_features
from features import FEATURE_NAMES, extract_features
from models import build_models
from reputation import domain_popularity, free_hosting
from url_utils import canonicalize, encode_chars, hostname

SEED = 42
REP_FEATURES = ["domain_popularity", "free_hosting"]            # Review-2 accuracy upgrade
HC_FEATURES = [f for f in FEATURE_NAMES if f != "uses_https"] + REP_FEATURES   # scheme removed
SVM_MAX_TRAIN = 20000                                             # RBF-SVM is O(n^2)

FAMILY = {
    "Logistic Regression": "Handcrafted + ML", "Decision Tree": "Handcrafted + ML",
    "Random Forest": "Handcrafted + ML", "SVM (RBF)": "Handcrafted + ML",
    "Gradient Boosting": "Handcrafted + ML", "MLP": "Handcrafted + DL",
    "Char-CNN": "Learned + DL", "Char-BiLSTM": "Learned + DL",
    "Hybrid CNN+Features": "Hybrid DL", "Char n-gram TF-IDF + LR": "Reference",
}
SLUG = {k: k.lower().replace(" ", "_").replace("(", "").replace(")", "")
        .replace("+", "plus").replace("-", "_") for k in FAMILY}


# --------------------------------------------------------------------------- #
def load_dataset(path):
    df = pd.read_csv(path)
    if "split" not in df.columns:                      # Review-1 synthetic csv
        df["url_raw"] = df["url"]
        df["url"] = df["url_raw"].map(canonicalize)
        df["host"] = df["url"].map(hostname)
        df["source"] = "synthetic"
        tr, te = train_test_split(df.index, test_size=0.2, stratify=df["label"],
                                  random_state=SEED)
        tr, va = train_test_split(tr, test_size=0.125,
                                  stratify=df.loc[tr, "label"], random_state=SEED)
        df["split"] = "train"
        df.loc[va, "split"] = "val"
        df.loc[te, "split"] = "test"
    return df.reset_index(drop=True)


def hc_matrix(urls):
    """Handcrafted features on the canonical URL: Review-1 extractor (27, scheme removed)
    + domain reputation (popularity in Chrome's top sites, free-hosting platform)."""
    rows = []
    for u in urls:
        f = extract_features("http://" + u)
        h = hostname(u)
        f["domain_popularity"] = domain_popularity(h)
        f["free_hosting"] = free_hosting(h)
        rows.append(f)
    return pd.DataFrame(rows, columns=FEATURE_NAMES + REP_FEATURES)[HC_FEATURES]


def metrics_at(y, p, thr=0.5):
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "accuracy": accuracy_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
        "recall": recall_score(y, pred), "f1": f1_score(y, pred),
        "roc_auc": roc_auc_score(y, p), "pr_auc": average_precision_score(y, p),
        "fpr": fp / (fp + tn), "fnr": fn / (fn + tp),
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
    }


def threshold_for_fpr(y_val, p_val, target=0.01):
    """Smallest threshold whose validation FPR <= target."""
    neg = np.sort(p_val[y_val == 0])
    k = int(np.floor(target * len(neg)))
    return float(neg[-k - 1]) + 1e-9 if k < len(neg) else 0.5


def bootstrap_f1(y, p, thr=0.5, n=1000, seed=SEED):
    rng = np.random.RandomState(seed)
    pred = (p >= thr).astype(int)
    idx = np.arange(len(y))
    s = [f1_score(y[b], pred[b]) for b in (rng.choice(idx, len(idx)) for _ in range(n))]
    return np.percentile(s, 2.5), np.percentile(s, 97.5)


def mcnemar(y, pa, pb, thr=0.5):
    a = (pa >= thr) == y
    b = (pb >= thr) == y
    n01, n10 = int((a & ~b).sum()), int((~a & b).sum())
    stat = (abs(n01 - n10) - 1) ** 2 / (n01 + n10) if (n01 + n10) else 0.0
    return n01, n10, stat, float(chi2.sf(stat, 1))


def _size_kb(obj):
    buf = io.BytesIO()
    joblib.dump(obj, buf, compress=3)
    return buf.tell() / 1024


# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/real_urls.csv")
    ap.add_argument("--tag", default="real")
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--no-save", action="store_true")
    args = ap.parse_args()
    real = args.tag == "real"
    prefix = "r2" if real else f"r2_{args.tag}"
    os.makedirs("results", exist_ok=True)
    os.makedirs("models", exist_ok=True)
    plots_dir = os.path.join("plots", prefix)
    os.makedirs(plots_dir, exist_ok=True)
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    df = load_dataset(args.data)
    tr, va, te = (df[df.split == s].reset_index(drop=True) for s in ("train", "val", "test"))
    print(f"[data] {args.data}: train={len(tr)} val={len(va)} test={len(te)} "
          f"phish%={df.label.mean():.2f}")

    # ---------------- handcrafted features (selection fit on TRAIN only) -----
    t0 = time.time()
    Xtr_all, Xva_all, Xte_all = hc_matrix(tr.url), hc_matrix(va.url), hc_matrix(te.url)
    print(f"[features] {Xtr_all.shape[1]} handcrafted features ({time.time()-t0:.0f}s)")
    selected, ranking = select_features(Xtr_all, tr.label, plots_dir=plots_dir)
    ranking.to_csv(f"results/{prefix}_feature_ranking.csv")
    Xtr, Xva, Xte = Xtr_all[selected], Xva_all[selected], Xte_all[selected]
    ytr, yva, yte = tr.label.values, va.label.values, te.label.values

    scaler = StandardScaler().fit(Xtr)
    def fz(X):
        return np.clip(scaler.transform(X), -6, 6).astype(np.float32)
    Ftr, Fva, Fte = fz(Xtr), fz(Xva), fz(Xte)
    Ctr, Cva, Cte = encode_chars(tr.url), encode_chars(va.url), encode_chars(te.url)

    rows, test_probs, val_probs, history, fitted = [], {}, {}, {}, {}

    # ---------------- classic ML on handcrafted features ---------------------
    ml = build_models()
    ml["Gradient Boosting"] = Pipeline([("clf", HistGradientBoostingClassifier(
        max_iter=400, learning_rate=0.08, max_leaf_nodes=63, random_state=SEED))])
    for name, model in ml.items():
        print(f"\n[ML] {name}")
        t0 = time.time()
        if name.startswith("SVM") and len(Xtr) > SVM_MAX_TRAIN:
            sub = np.random.RandomState(SEED).choice(len(Xtr), SVM_MAX_TRAIN, replace=False)
            model.fit(Xtr.iloc[sub], ytr[sub])
        else:
            model.fit(Xtr, ytr)
        fit_s = time.time() - t0
        if "clf" in model.named_steps and hasattr(model.named_steps["clf"], "n_jobs"):
            model.named_steps["clf"].set_params(n_jobs=1)
        val_probs[name] = model.predict_proba(Xva)[:, 1]
        test_probs[name] = model.predict_proba(Xte)[:, 1]
        fitted[name] = ("sk", model)
        rows.append({"model": name, "train_s": fit_s, "size_kb": _size_kb(model),
                     "params": np.nan})

    # ---------------- reference: char n-gram TF-IDF + LR ---------------------
    name = "Char n-gram TF-IDF + LR"
    print(f"\n[REF] {name}")
    t0 = time.time()
    tfidf = Pipeline([
        ("tfidf", TfidfVectorizer(analyzer="char", ngram_range=(2, 5), min_df=3,
                                  max_features=300000, sublinear_tf=True)),
        ("clf", LogisticRegression(C=5, max_iter=3000)),
    ]).fit(tr.url, ytr)
    val_probs[name] = tfidf.predict_proba(va.url)[:, 1]
    test_probs[name] = tfidf.predict_proba(te.url)[:, 1]
    fitted[name] = ("text", tfidf)
    rows.append({"model": name, "train_s": time.time() - t0,
                 "size_kb": _size_kb(tfidf), "params": np.nan})

    # ---------------- deep learning ------------------------------------------
    nf = Ftr.shape[1]
    dl_specs = [
        ("MLP", "FeatureMLP", {"n_feats": nf}, 1e-3),
        ("Char-CNN", "CharCNN", {}, 2e-3),
        ("Char-BiLSTM", "CharBiLSTM", {}, 2e-3),
        ("Hybrid CNN+Features", "HybridCNN", {"n_feats": nf}, 2e-3),
    ]
    ctor = {"FeatureMLP": FeatureMLP, "CharCNN": CharCNN,
            "CharBiLSTM": CharBiLSTM, "HybridCNN": HybridCNN}
    for name, kind, kw, lr in dl_specs:
        print(f"\n[DL] {name}  ({kind})")
        torch.manual_seed(SEED)
        m = ctor[kind](**kw)
        pack = lambda C, F, y: {"chars": C if USES_CHARS[kind] else None,
                                "feats": F if USES_FEATS[kind] else None, "y": y}
        t0 = time.time()
        m, hist = train_model(m, pack(Ctr, Ftr, ytr), pack(Cva, Fva, yva),
                              epochs=args.epochs, lr=lr, seed=SEED)
        fit_s = time.time() - t0
        history[name] = hist
        P = lambda C, F: predict_proba(m, C if USES_CHARS[kind] else None,
                                       F if USES_FEATS[kind] else None)
        val_probs[name], test_probs[name] = P(Cva, Fva), P(Cte, Fte)
        fitted[name] = ("dl", (m, kind, kw))
        sd = io.BytesIO()
        torch.save(m.state_dict(), sd)
        rows.append({"model": name, "train_s": fit_s, "size_kb": sd.tell() / 1024,
                     "params": n_params(m), "epochs": len(hist)})

    # ---------------- single-URL latency (end-to-end, ms) --------------------
    sample = te.url_raw.sample(300, random_state=SEED).tolist()
    for r in rows:
        name = r["model"]
        kind, obj = fitted[name]
        times = []
        for u in sample:
            t0 = time.perf_counter()
            c = canonicalize(u)
            if kind == "sk":
                x = hc_matrix([c])[selected]
                obj.predict_proba(x)
            elif kind == "text":
                obj.predict_proba([c])
            else:
                m, k, _ = obj
                C = encode_chars([c]) if USES_CHARS[k] else None
                F = fz(hc_matrix([c])[selected]) if USES_FEATS[k] else None
                predict_proba(m, C, F)
            times.append((time.perf_counter() - t0) * 1000)
        r["latency_ms"] = float(np.median(times))

    # ---------------- metrics -------------------------------------------------
    out = []
    for r in rows:
        name = r["model"]
        p, pv = test_probs[name], val_probs[name]
        mt = metrics_at(yte, p)
        thr1 = threshold_for_fpr(yva, pv, 0.01)
        m1 = metrics_at(yte, p, thr1)
        lo, hi = bootstrap_f1(yte, p)
        out.append({"model": name, "family": FAMILY[name], **mt,
                    "f1_ci_low": lo, "f1_ci_high": hi,
                    "thr_at_1pct_fpr": thr1, "recall_at_1pct_fpr": m1["recall"],
                    "test_fpr_at_that_thr": m1["fpr"], **{k: v for k, v in r.items() if k != "model"}})
    met = pd.DataFrame(out).set_index("model")
    met.to_csv(f"results/{prefix}_metrics.csv")

    # predictions
    pcols = {f"p_{SLUG[n]}": test_probs[n] for n in test_probs}
    pd.concat([te[["url", "url_raw", "host", "source", "label"]], pd.DataFrame(pcols)],
              axis=1).to_csv(f"results/{prefix}_test_predictions.csv", index=False)
    pcols = {f"p_{SLUG[n]}": val_probs[n] for n in val_probs}
    pd.concat([va[["url", "host", "source", "label"]], pd.DataFrame(pcols)],
              axis=1).to_csv(f"results/{prefix}_val_predictions.csv", index=False)
    with open(f"results/{prefix}_dl_history.json", "w") as f:
        json.dump(history, f, indent=1)

    # significance: best handcrafted-ML vs each DL model
    ml_names = [n for n in met.index if FAMILY[n] == "Handcrafted + ML"]
    best_ml = met.loc[ml_names, "f1"].idxmax()
    sig = []
    for n in ["MLP", "Char-CNN", "Char-BiLSTM", "Hybrid CNN+Features", "Char n-gram TF-IDF + LR"]:
        n01, n10, stat, pval = mcnemar(yte, test_probs[best_ml], test_probs[n])
        sig.append({"model_a": best_ml, "model_b": n, "a_right_b_wrong": n01,
                    "a_wrong_b_right": n10, "chi2": stat, "p_value": pval})
    pd.DataFrame(sig).to_csv(f"results/{prefix}_significance.csv", index=False)

    # ---------------- save artefacts for the interface -----------------------
    if real and not args.no_save:
        keep_ml = ["Gradient Boosting", "Logistic Regression"]   # RF pickle is >100 MB
        for n in keep_ml:
            joblib.dump(fitted[n][1], f"models/ml_{SLUG[n]}.joblib", compress=3)
        joblib.dump(scaler, "models/feature_scaler.joblib")
        for n, kind, kw, _ in dl_specs:
            save_dl(fitted[n][1][0], kind, kw, f"models/dl_{SLUG[n]}.pt")
        meta = {"selected_features": selected, "hc_features": HC_FEATURES,
                "best_ml": best_ml, "n_train": int(len(tr)), "n_val": int(len(va)),
                "n_test": int(len(te)),
                "thresholds_1pct_fpr": {n: float(met.loc[n, "thr_at_1pct_fpr"]) for n in met.index},
                "test_metrics": met[["precision", "recall", "f1", "roc_auc", "fpr", "fnr"]]
                .round(4).to_dict(orient="index"),
                "ml_files": {n: f"ml_{SLUG[n]}.joblib" for n in keep_ml},
                "dl_files": {n: f"dl_{SLUG[n]}.pt" for n, *_ in dl_specs}}
        with open("models/meta.json", "w") as f:
            json.dump(meta, f, indent=2)

    cols = ["family", "precision", "recall", "f1", "roc_auc", "pr_auc", "fpr", "fnr",
            "recall_at_1pct_fpr", "latency_ms", "size_kb"]
    print("\n" + "=" * 100)
    print(f"REVIEW 2 RESULTS  ({args.tag}, test n={len(te)})")
    print("=" * 100)
    print(met[cols].sort_values("f1", ascending=False).round(4).to_string())
    print("\nMcNemar vs", best_ml)
    print(pd.DataFrame(sig).round(5).to_string(index=False))


if __name__ == "__main__":
    main()
