"""
sanity_check.py
---------------
Real-world spot check outside the benchmark:
  * data/sanity/familiar_legit_urls.txt   - 54 everyday legitimate URLs (Indian + global sites)
  * data/sanity/openphish_2026-11-13.txt  - live OpenPhish feed (hosts excluded from training)
Reports, per model, false alarms on the familiar sites and detection rate on the live feed.

    python sanity_check.py [--models models] [--out results/r2_sanity.csv]
"""
import argparse, os, sys
import numpy as np, pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--models", default="models")
ap.add_argument("--out", default="results/r2_sanity.csv")
a = ap.parse_args()
from predictor import PhishPredictor
from url_utils import canonicalize, hostname

pp = PhishPredictor(a.models)
legit = [l.strip() for l in open("data/sanity/familiar_legit_urls.txt") if l.strip()]
feed = [l.strip() for l in open("data/sanity/openphish_2026-11-13.txt") if l.strip()]
known = set(pd.read_csv("data/real_urls.csv", usecols=["host"]).host)
fd = pd.DataFrame({"u": feed}); fd["h"] = fd.u.map(hostname)
fd = fd[~fd.h.isin(known)].drop_duplicates("h")
L = pp.predict_all(legit); P = pp.predict_all(fd.u.tolist())
rows = []
for m in pp.names:
    t1 = pp.threshold(m, "low_fpr")
    rows.append({"model": m, "familiar_false_alarms@0.5": int((L[m] >= .5).sum()), "familiar_n": len(L),
                 "live_detect@0.5": float((P[m] >= .5).mean()), "live_detect@1%FPR": float((P[m] >= t1).mean()),
                 "live_n": len(P)})
res = pd.DataFrame(rows)
res.to_csv(a.out, index=False)
pd.set_option("display.width", 200)
print(res.round(3).to_string(index=False))
m0 = pp.names[0]
print(f"\nfamiliar sites flagged by {m0}:", L[L[m0] >= .5][["url", m0]].round(3).to_string(index=False) if (L[m0] >= .5).any() else "none")
L.round(4).to_csv(a.out.replace(".csv", "_familiar_scores.csv"), index=False)
P.round(4).to_csv(a.out.replace(".csv", "_live_scores.csv"), index=False)
