"""
reputation.py
-------------
Domain-reputation features added in Review 2 (accuracy upgrade).

  domain_popularity : how popular the URL's site is, from the public Chrome UX
                      Report (CrUX) top-1M list (Google, via github.com/zakird/
                      crux-top-lists). Levels: 5 = top 1k, 4 = top 5k, 3 = top 10k,
                      2 = top 50k, 1 = top 100k, 0 = not in the top 100k.
                      Lookup is on the exact host and on its *registrable domain*
                      computed with the Public Suffix List INCLUDING private
                      suffixes, so  evil.web.app / x.pages.dev / y.github.io  do NOT
                      inherit the popularity of web.app / pages.dev / github.io.
  free_hosting      : 1 if the host is on a free web-hosting / cloud platform where
                      anyone can publish (weebly, firebaseapp, pages.dev, ...).

Phishing sites are almost never in the top-100k (they live for days), while the
sites people actually use are - exactly the signal real browser filters use
(UCI's phishing dataset has the same idea as its 'web_traffic' / 'page_rank').

    python reputation.py      # builds data/reputation/popular_domains_top100k.json
"""
import gzip
import json
import os
import re

from explain import FREE_HOSTING

HERE = os.path.dirname(os.path.abspath(__file__))
REP_DIR = os.path.join(HERE, "data", "reputation")
PSL_PATH = os.path.join(REP_DIR, "public_suffix_list.dat")
POP_PATH = os.path.join(REP_DIR, "popular_domains_top100k.json")
CRUX_PATH = os.path.join(HERE, "data", "raw", "crux_global_top1m.csv.gz")
CRUX_URL = "https://raw.githubusercontent.com/zakird/crux-top-lists/main/data/global/current.csv.gz"
LEVEL = {1000: 5, 5000: 4, 10000: 3, 50000: 2, 100000: 1}

# ------------------------------------------------------------ public suffix list
_RULES = None


def _load_psl():
    global _RULES
    if _RULES is None:
        normal, wild, exc = set(), set(), set()
        for line in open(PSL_PATH, encoding="utf-8"):
            r = line.strip().split(" ")[0]
            if not r or r.startswith("//"):
                continue
            r = r.lower()
            if r.startswith("!"):
                exc.add(r[1:])
            elif r.startswith("*."):
                wild.add(r[2:])
            else:
                normal.add(r)
        _RULES = (normal, wild, exc)
    return _RULES


def registrable_domain(host):
    """eTLD+1 of host using PSL incl. private section ('' for IPs / bare suffixes)."""
    host = host.strip(".").lower()
    if not host or re.fullmatch(r"[\d.]+", host):
        return ""
    normal, wild, exc = _load_psl()
    labels = host.split(".")
    n = len(labels)
    suffix_len = 1                                  # default rule "*"
    for i in range(n):
        cand = ".".join(labels[i:])
        if cand in exc:
            suffix_len = n - i - 1
            break
        if cand in normal or ".".join(labels[i + 1:]) in wild and i + 1 < n:
            suffix_len = n - i
            break
    if n <= suffix_len:
        return ""
    return ".".join(labels[n - suffix_len - 1:])


# ------------------------------------------------------------ popularity table
_POP = None


def _strip_www(h):
    return re.sub(r"^www\d{0,2}\.", "", h)


def build_popularity(top=100000):
    import urllib.request
    if not os.path.exists(CRUX_PATH):
        os.makedirs(os.path.dirname(CRUX_PATH), exist_ok=True)
        urllib.request.urlretrieve(CRUX_URL, CRUX_PATH)
    table = {}
    with gzip.open(CRUX_PATH, "rt", encoding="utf-8") as f:
        next(f)
        for line in f:
            origin, rank = line.rstrip("\n").rsplit(",", 1)
            rank = int(rank)
            if rank > top:
                continue
            host = re.sub(r"^[a-z]+://", "", origin.lower()).split("/")[0].split(":")[0]
            host = _strip_www(host)
            lvl = LEVEL[rank]
            for key in (host, registrable_domain(host)):
                if key and table.get(key, 0) < lvl:
                    table[key] = lvl
    json.dump(table, open(POP_PATH, "w"), separators=(",", ":"), sort_keys=True)
    return table


def _pop():
    global _POP
    if _POP is None:
        _POP = json.load(open(POP_PATH)) if os.path.exists(POP_PATH) else build_popularity()
    return _POP


def domain_popularity(host):
    host = _strip_www(host.strip(".").lower())
    t = _pop()
    return max(t.get(host, 0), t.get(registrable_domain(host), 0))


def free_hosting(host):
    host = host.lower()
    return int(any(host == d or host.endswith("." + d) for d in FREE_HOSTING) or "ipfs" in host)


if __name__ == "__main__":
    t = build_popularity()
    print(f"popularity table: {len(t):,} hosts/domains -> {POP_PATH}")
    for h in ["mail.google.com", "sbi.co.in", "onlinesbi.sbi", "amazon.in", "irctc.co.in", "github.com",
              "metamask-x.web.app", "x.pages.dev", "secure-chase-verify.weebly.com", "iiits.ac.in",
              "hdfcbank.com", "paytm.com", "flipkart.com", "appleid.apple.com-sa.pm"]:
        print(f"  {h:32s} rd={registrable_domain(h):22s} popularity={domain_popularity(h)} free_hosting={free_hosting(h)}")
