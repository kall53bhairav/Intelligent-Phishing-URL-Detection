"""
parity_test.py — checks that the browser port (phishcore.js) reproduces the
Python models: same canonical form, same 28 features, same red flags, same
probabilities (all 6 models) and same occlusion saliency.

    python web_demo/parity_test.py        (needs node)
"""
import json, os, subprocess, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from predictor import PhishPredictor
from features import extract_features, FEATURE_NAMES
from explain import red_flags

HERE = os.path.dirname(os.path.abspath(__file__))
edge = ["HTTPS://WWW.PayPal.com/", "http://user@1.2.3.4:8080/x", "ftp://files.example.org/a;b/c;d?x=1#frag",
        "http://xn--pple-43d.com/login", "paypal.com", "www2.bank.co.uk/a/b/", "http://198.51.100.7/login.php",
        "https://exa mple.com/ sp", "http://a.b.c.d.e.example.tk/verify?acc=1&x=2&&y=", "münchen.de/über",
        "http://example.com:abc/path", "//no-scheme.com/x", "http://[2001:db8::1]/x", "secure-login.paypa1-verify.xyz/account?id=9",
        "metamask-wallet-recovery.web.app", "bit.ly/3xYz12", "http://example.com/%20%41;jsessionid=12?q=1",
        "https://mail.google.com/mail/u/0/#inbox", "a", "x" * 300]
te = pd.read_csv("results/r2_test_predictions.csv").sample(1500, random_state=7).url_raw.tolist()
feeds = []
for f in ["data/sanity/openphish_2026-11-13.txt", "data/sanity/familiar_legit_urls.txt"]:
    if os.path.exists(f):
        feeds += [l.strip() for l in open(f) if l.strip()][:400]
urls = edge + te + feeds
pp = PhishPredictor()
res = pp.predict_all(urls)
exp = {"urls": urls, "canonical": res.canonical.tolist(),
       "probs": {n: res[n].astype(float).tolist() for n in pp.names},
       "features": [[float(v) for v in extract_features(u).values()] for u in urls],
       "flags": [[list(x) for x in red_flags(u)] for u in urls],
       "sal": {}}
for u in edge[:6] + te[:6]:
    for m in ["Hybrid CNN+Features", "Char-CNN"]:
        c, base, sc = pp.saliency(u, m)
        exp["sal"][f"{m}|{u}"] = {"base": float(base), "scores": [float(x) for x in sc]}
json.dump(exp, open("/tmp/parity_expected.json", "w"))
out = subprocess.run(["node", os.path.join(HERE, "parity_check.js"), "/tmp/parity_expected.json",
                      os.path.join(HERE, "model_bundle.json")], capture_output=True, text=True)
print(out.stdout, out.stderr)
