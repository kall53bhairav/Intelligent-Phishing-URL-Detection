/*
 * phishcore.js — browser/Node port of the Review-2 inference pipeline.
 *
 * Mirrors, line for line:
 *   url_utils.py   canonicalize(), hostname(), encode_chars()
 *   features.py    extract_features()  (incl. Python urllib.parse.urlparse rules)
 *   explain.py     red_flags(), char_occlusion()
 *   dl_models.py   CharCNN, CharBiLSTM, FeatureMLP, HybridCNN forward passes (eval mode)
 *   sklearn        StandardScaler + LogisticRegression, HistGradientBoosting trees
 * Weights come from model_bundle.json (web_demo/export_web_models.py).
 * Verified against the Python models in web_demo/parity_test.py.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.PhishCore = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // ------------------------------------------------------------------ constants
  const FEATURE_NAMES = [
    "url_length", "num_dots", "num_hyphens", "num_at", "num_question",
    "num_equals", "num_underscore", "num_percent", "num_ampersand",
    "num_digits", "num_special", "digit_ratio", "special_ratio", "url_entropy",
    "num_subdomains", "path_length", "num_path_segments", "query_length",
    "num_query_params", "has_port",
    "uses_https", "has_ip", "host_length", "host_digit_ratio", "tld_length",
    "suspicious_tld", "has_punycode", "num_keywords",
  ];
  const SUSPICIOUS_TLDS = new Set(["tk", "ml", "ga", "cf", "gq", "xyz", "top", "click",
    "info", "zip", "work", "party", "review", "country"]);
  const PHISH_KEYWORDS = ["secure", "verify", "account", "update", "login", "signin",
    "confirm", "webscr", "banking", "bank", "alert", "suspended",
    "billing", "recover", "unlock", "validation", "password", "pay"];
  const FREE_HOSTING = ["firebaseapp.com", "web.app", "godaddysites.com", "weebly.com", "wixsite.com",
    "wix.com", "blogspot.com", "github.io", "netlify.app", "vercel.app",
    "pages.dev", "workers.dev", "repl.co", "replit.app", "glitch.me",
    "herokuapp.com", "azurewebsites.net", "cloudfront.net", "appspot.com",
    "ipfs.io", "cloudflare-ipfs.com", "dweb.link", "000webhostapp.com",
    "sharepoint.com", "sites.google.com", "wordpress.com", "square.site",
    "webflow.io", "mystrikingly.com", "surge.sh", "r2.dev", "amazonaws.com",
    "onrender.com", "translate.goog", "framer.app", "framer.website",
    "carrd.co", "gitbook.io", "my.site.com", "ngrok.io", "ngrok-free.app",
    "hostingersite.com", "jimdosite.com", "webcindario.com", "yolasite.com",
    "site123.me", "business.site", "ukit.me", "tilda.ws", "temp.domains",
    "ipfs.w3s.link", "nftstorage.link", "fleek.co", "on.fleek.co", "glide.page"];
  const BRANDS = ["paypal", "apple", "microsoft", "office", "outlook", "amazon", "netflix",
    "google", "facebook", "instagram", "whatsapp", "metamask", "coinbase",
    "binance", "bank", "chase", "wellsfargo", "dhl", "fedex", "usps", "ups",
    "adobe", "dropbox", "docusign", "linkedin", "steam", "roblox", "att",
    "verizon", "irs", "gov", "wallet", "ledger", "trezor", "crypto", "nft",
    "auth", "sso", "owa", "webmail", "mail"];
  const SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd",
    "cutt.ly", "rb.gy", "shorturl.at", "rebrand.ly", "t.ly", "s.id"];
  const USES_PARAMS = new Set(["", "ftp", "hdl", "prospero", "http", "imap", "https", "shttp",
    "rtsp", "rtsps", "rtspu", "sip", "sips", "mms", "sftp", "tel"]);
  const SCHEME_CHARS = /^[A-Za-z0-9+\-.]$/;
  const MAX_LEN = 256, PAD = 0, UNK = 1;

  // --------------------------------------------------------------- py helpers
  const cps = (s) => Array.from(s);                       // Python len()/iteration = code points
  const isDigit = (c) => /\p{Nd}/u.test(c);                // str.isdigit
  const isAlnum = (c) => /[\p{L}\p{N}]/u.test(c);          // str.isalnum
  const countChar = (s, ch) => s.split(ch).length - 1;     // str.count(single char)
  const IP_RE = /^(?:\p{Nd}{1,3}\.){3}\p{Nd}{1,3}$/u;
  const pyStrip = (s) => s.replace(/^[\s\u001c-\u001f]+|[\s\u001c-\u001f]+$/gu, "");

  function neumaierSum(xs) { // Python >= 3.12 float sum()
    let s = 0.0, c = 0.0;
    for (const x of xs) {
      const t = s + x;
      if (Math.abs(s) >= Math.abs(x)) c += (s - t) + x; else c += (x - t) + s;
      s = t;
    }
    return c && Number.isFinite(c) ? s + c : s;
  }

  // ---------------------------------------------------------- url_utils.py
  function canonicalize(url) {
    let u = pyStrip(String(url));
    u = u.replace(/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\//, "");
    u = u.replace(/^www\d{0,2}\./i, "");
    const m = u.match(/^([^/?#]*)(.*)$/);
    const host = m ? m[1] : u, rest = m ? m[2] : "";
    u = host.toLowerCase() + rest;
    return u.replace(/\/+$/, "");
  }
  function hostname(url) {
    const c = canonicalize(url);
    let host = c.match(/^([^/?#]*)/)[1];
    host = host.split("@").pop();
    return host.split(":")[0];
  }
  function encodeChars(u) {
    return cps(String(u)).slice(0, MAX_LEN).map((ch) => {
      const k = ch.codePointAt(0);
      return k >= 32 && k <= 126 ? k - 30 : UNK;
    });
  }

  // ------------------------------------------- urllib.parse.urlparse (subset)
  function urlparse(url) {
    url = url.replace(/[\t\r\n]/g, "");
    let scheme = "", netloc = "", query = "", fragment = "", params = "";
    const i = url.indexOf(":");
    if (i > 0 && /^[A-Za-z]$/.test(url[0])) {
      const cand = url.slice(0, i);
      if ([...cand].every((c) => SCHEME_CHARS.test(c))) { scheme = cand.toLowerCase(); url = url.slice(i + 1); }
    }
    if (url.slice(0, 2) === "//") {
      let delim = url.length;
      for (const c of "/?#") { const w = url.indexOf(c, 2); if (w >= 0) delim = Math.min(delim, w); }
      netloc = url.slice(2, delim); url = url.slice(delim);
    }
    if (url.includes("#")) { const k = url.indexOf("#"); fragment = url.slice(k + 1); url = url.slice(0, k); }
    if (url.includes("?")) { const k = url.indexOf("?"); query = url.slice(k + 1); url = url.slice(0, k); }
    if (USES_PARAMS.has(scheme) && url.includes(";")) {
      let k;
      if (url.includes("/")) { k = url.indexOf(";", url.lastIndexOf("/")); if (k < 0) k = null; }
      else k = url.indexOf(";");
      if (k !== null) { params = url.slice(k + 1); url = url.slice(0, k); }
    }
    return { scheme, netloc, path: url, params, query, fragment };
  }
  function splitHost(netloc) {
    if (netloc.includes("@")) netloc = netloc.split("@").pop();
    let port = null;
    if (netloc.includes(":")) {
      const k = netloc.lastIndexOf(":"), host = netloc.slice(0, k), maybe = netloc.slice(k + 1);
      if (maybe.length && cps(maybe).every(isDigit)) { port = maybe; netloc = host; }
    }
    return [netloc, port];
  }
  function entropy(s) {
    const a = cps(s);
    if (!a.length) return 0.0;
    const freq = new Map();
    for (const ch of a) freq.set(ch, (freq.get(ch) || 0) + 1);
    const n = a.length, terms = [];
    for (const c of freq.values()) terms.push((c / n) * Math.log2(c / n));
    return -neumaierSum(terms);
  }

  // ------------------------------------------------------------ features.py
  function extractFeatures(rawUrl) {
    const url = pyStrip(String(rawUrl));
    const target = url.includes("://") ? url : "http://" + url;
    const p = urlparse(target);
    const [host, port] = splitHost(p.netloc);
    const path = p.path || "", query = p.query || "";
    const U = cps(url);
    const length = U.length ? U.length : 1;
    const digits = U.filter(isDigit).length;
    const specials = U.filter((c) => !isAlnum(c)).length;
    const hasIp = IP_RE.test(host) ? 1 : 0;
    const H = cps(host);
    const hostDigits = H.filter(isDigit).length;
    const labels = host ? host.split(".") : [];
    const tld = labels.length >= 1 && !hasIp ? labels[labels.length - 1].toLowerCase() : "";
    const numSub = hasIp || labels.length <= 2 ? 0 : labels.length - 2;
    const lower = url.toLowerCase();
    const numKw = PHISH_KEYWORDS.filter((k) => lower.includes(k)).length;
    const qparams = query ? query.split("&").filter((x) => x) : [];
    const segs = path.split("/").filter((x) => x);
    return {
      url_length: length, num_dots: countChar(url, "."), num_hyphens: countChar(url, "-"),
      num_at: countChar(url, "@"), num_question: countChar(url, "?"), num_equals: countChar(url, "="),
      num_underscore: countChar(url, "_"), num_percent: countChar(url, "%"), num_ampersand: countChar(url, "&"),
      num_digits: digits, num_special: specials, digit_ratio: digits / length, special_ratio: specials / length,
      url_entropy: entropy(url), num_subdomains: numSub, path_length: cps(path).length,
      num_path_segments: segs.length, query_length: cps(query).length, num_query_params: qparams.length,
      has_port: port ? 1 : 0, uses_https: p.scheme === "https" ? 1 : 0, has_ip: hasIp,
      host_length: H.length, host_digit_ratio: H.length ? hostDigits / H.length : 0.0, tld_length: cps(tld).length,
      suspicious_tld: SUSPICIOUS_TLDS.has(tld) ? 1 : 0, has_punycode: lower.includes("xn--") ? 1 : 0,
      num_keywords: numKw,
    };
  }

  // ----------------------------------------------------------- reputation.py
  let REP = null;
  function setReputation(rep) {
    REP = { normal: new Set(rep.psl.normal), wild: new Set(rep.psl.wild), exc: new Set(rep.psl.exc), pop: new Map() };
    for (const [lvl, keys] of Object.entries(rep.pop)) for (const k of keys.split("\n")) if (k) REP.pop.set(k, +lvl);
  }
  const stripDots = (h) => h.replace(/^\.+|\.+$/g, "");
  const stripWww = (h) => h.replace(/^www\d{0,2}\./, "");
  function registrableDomain(host) {
    host = stripDots(host).toLowerCase();
    if (!host || /^[\d.]+$/.test(host)) return "";
    const labels = host.split("."), n = labels.length;
    let suf = 1;
    for (let i = 0; i < n; i++) {
      const cand = labels.slice(i).join(".");
      if (REP.exc.has(cand)) { suf = n - i - 1; break; }
      if (REP.normal.has(cand) || (REP.wild.has(labels.slice(i + 1).join(".")) && i + 1 < n)) { suf = n - i; break; }
    }
    if (n <= suf) return "";
    return labels.slice(n - suf - 1).join(".");
  }
  function domainPopularity(host) {
    const h = stripWww(stripDots(host).toLowerCase());
    return Math.max(REP.pop.get(h) || 0, REP.pop.get(registrableDomain(h)) || 0);
  }
  const freeHosting = (host) => (isFreeHosting(host.toLowerCase()) ? 1 : 0);
  function pctHalfEven(x) {          // Python f"{x:.0%}"
    const v = x * 100; let r = Math.round(v);
    if (Math.abs(v - Math.trunc(v)) === 0.5 && r % 2 !== 0) r -= 1;
    return r;
  }

  // -------------------------------------------------------------- explain.py
  const isFreeHosting = (host) => FREE_HOSTING.some((d) => host === d || host.endsWith("." + d)) || host.includes("ipfs");
  function redFlags(rawUrl) {
    const url = pyStrip(String(rawUrl));
    const f = extractFeatures(url.split("?")[0].includes("://") ? url : "http://" + url);
    const host = hostname(url), low = url.toLowerCase(), flags = [];
    if (f.has_ip) flags.push(["IP-address host", host, "high"]);
    if (f.num_at) flags.push(["'@' in URL", "browser ignores everything before '@'", "high"]);
    if (f.has_punycode) flags.push(["Punycode (IDN) host", "possible homograph look-alike", "high"]);
    if (isFreeHosting(host)) flags.push(["Free-hosting / cloud platform", host, "medium"]);
    if (SHORTENERS.includes(host)) flags.push(["URL shortener", "real destination hidden", "medium"]);
    if (f.suspicious_tld) flags.push(["Frequently-abused TLD", "." + host.split(".").pop(), "medium"]);
    const kw = PHISH_KEYWORDS.filter((k) => low.includes(k)).sort();
    if (kw.length) flags.push(["Credential-lure keywords", kw.slice(0, 5).join(", "), "medium"]);
    const fh = isFreeHosting(host);
    const rdLabel = fh ? "" : (registrableDomain(host) || host).split(".")[0];
    const trusted = domainPopularity(host) > 0 && !fh;
    const br = trusted ? [] : BRANDS.filter((b) => host.includes(b) && !rdLabel.includes(b)).sort();
    if (br.length) flags.push(["Brand / service name inside host", br.slice(0, 4).join(", "), "medium"]);
    if (f.num_subdomains >= 3) flags.push(["Many sub-domains", `${f.num_subdomains} levels`, "medium"]);
    const hy = countChar(host, "-");
    if (hy >= 2) flags.push(["Hyphen-heavy host", `${hy} hyphens`, "info"]);
    if (f.host_digit_ratio > 0.2) flags.push(["Digit-heavy host", `${pctHalfEven(f.host_digit_ratio)}% digits`, "info"]);
    if (f.url_length > 90) flags.push(["Very long URL", `${f.url_length} chars`, "info"]);
    if (!flags.length) flags.push(["No rule-based red flags", "decision rests on learned patterns", "info"]);
    let out = trusted ? flags.map(([n, d, sev]) => [n, d, n === "Credential-lure keywords" ? "info" : sev]) : flags;
    const pop = domainPopularity(host);
    if (pop && !fh) out = [["Well-known domain", `in Chrome's top-${{ 5: "1k", 4: "5k", 3: "10k", 2: "50k", 1: "100k" }[pop]} sites`, "good"]].concat(out);
    return out;
  }

  // ------------------------------------------------------------ tensor utils
  function b64bytes(b64) {
    if (typeof Buffer !== "undefined") { const b = Buffer.from(b64, "base64"); return new Uint8Array(b.buffer, b.byteOffset, b.length); }
    const s = atob(b64), u = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
    return u;
  }
  const typed = (b64, T) => { const u = b64bytes(b64); const c = new Uint8Array(u); return new T(c.buffer); };
  const T = (t) => typed(t.data, Float32Array);
  const sig = (x) => 1 / (1 + Math.exp(-x));
  function linear(W, b, x, nOut, nIn) {
    const y = new Float64Array(nOut);
    for (let o = 0; o < nOut; o++) { let s = b[o]; const r = o * nIn; for (let i = 0; i < nIn; i++) s += W[r + i] * x[i]; y[o] = s; }
    return y;
  }
  const relu = (v) => { for (let i = 0; i < v.length; i++) if (v[i] < 0) v[i] = 0; return v; };
  function bn(v, w, b, rm, rv) { for (let i = 0; i < v.length; i++) v[i] = (v[i] - rm[i]) / Math.sqrt(rv[i] + 1e-5) * w[i] + b[i]; return v; }

  // ------------------------------------------------------------- the models
  function buildCNN(sd, prefix) {
    const E = 48, F = 128;
    return {
      E, F, emb: T(sd[prefix + "emb.weight"]),
      convs: [0, 1, 2].map((i) => ({ w: T(sd[`${prefix}convs.${i}.weight`]), b: T(sd[`${prefix}convs.${i}.bias`]), k: sd[`${prefix}convs.${i}.weight`].shape[2] })),
    };
  }
  function embed(cnn, ids) {
    const L = ids.length, X = new Float64Array(L * cnn.E);
    for (let t = 0; t < L; t++) { const o = ids[t] * cnn.E; for (let e = 0; e < cnn.E; e++) X[t * cnn.E + e] = cnn.emb[o + e]; }
    return X;
  }
  function convAt(cnn, c, X, L, f, t) {   // relu(conv) for filter f at position t
    const { w, b, k } = cnn.convs[c], E = cnn.E, pad = k >> 1;
    let s = b[f];
    for (let j = 0; j < k; j++) {
      const pos = t - pad + j;
      if (pos < 0 || pos >= L) continue;
      const wo = f * E * k + j, xo = pos * E;
      for (let e = 0; e < E; e++) s += w[wo + e * k] * X[xo + e];
    }
    return s > 0 ? s : 0;
  }
  function cnnActs(cnn, ids) {            // A[c][f*L + t]
    const L = ids.length, X = embed(cnn, ids);
    const A = cnn.convs.map((_, c) => { const a = new Float64Array(cnn.F * L); for (let f = 0; f < cnn.F; f++) for (let t = 0; t < L; t++) a[f * L + t] = convAt(cnn, c, X, L, f, t); return a; });
    return { A, X, L };
  }
  function cnnPool(cnn, acts) {
    const { A, L } = acts, out = new Float64Array(cnn.F * 3);
    if (L === 0) return out.fill(-1e4);
    for (let c = 0; c < 3; c++) for (let f = 0; f < cnn.F; f++) {
      let m = -Infinity; const a = A[c];
      for (let t = 0; t < L; t++) if (a[f * L + t] > m) m = a[f * L + t];
      out[c * cnn.F + f] = m;
    }
    return out;
  }

  class Models {
    constructor(bundle) {
      this.meta = bundle.meta;
      setReputation(bundle.reputation);
      this.sel = bundle.meta.selected_features;
      this.sc = bundle.scaler; this.lrp = bundle.lr;
      const g = bundle.gb;
      this.gb = { base: g.baseline, roots: g.roots, feat: typed(g.feat, Int16Array), thr: typed(g.thr, Float64Array),
        left: typed(g.left, Int32Array), right: typed(g.right, Int32Array), leaf: typed(g.leaf, Uint8Array), value: typed(g.value, Float64Array) };
      const c = bundle.cnn;
      this.cnn = { enc: buildCNN(c, ""), h1w: T(c["head.1.weight"]), h1b: T(c["head.1.bias"]), h2w: T(c["head.4.weight"]), h2b: T(c["head.4.bias"]) };
      const l = bundle.bilstm, H = 96;
      this.lstm = { H, emb: T(l["emb.weight"]), dirs: ["", "_reverse"].map((s) => ({ wih: T(l["lstm.weight_ih_l0" + s]), whh: T(l["lstm.weight_hh_l0" + s]),
        b: (() => { const a = T(l["lstm.bias_ih_l0" + s]), bb = T(l["lstm.bias_hh_l0" + s]); return a.map((v, i) => v + bb[i]); })() })),
        h1w: T(l["head.1.weight"]), h1b: T(l["head.1.bias"]), h2w: T(l["head.4.weight"]), h2b: T(l["head.4.bias"]) };
      const m = bundle.mlp, bnp = (p) => [T(m[p + ".weight"]), T(m[p + ".bias"]), T(m[p + ".running_mean"]), T(m[p + ".running_var"])];
      this.mlp = { l0: [T(m["net.0.weight"]), T(m["net.0.bias"])], bn1: bnp("net.1"), l4: [T(m["net.4.weight"]), T(m["net.4.bias"])], bn5: bnp("net.5"), l8: [T(m["net.8.weight"]), T(m["net.8.bias"])] };
      const h = bundle.hybrid;
      this.hyb = { enc: buildCNN(h, "cnn."), fw: T(h["fbranch.0.weight"]), fb: T(h["fbranch.0.bias"]),
        fbn: [T(h["fbranch.1.weight"]), T(h["fbranch.1.bias"]), T(h["fbranch.1.running_mean"]), T(h["fbranch.1.running_var"])],
        h1w: T(h["head.1.weight"]), h1b: T(h["head.1.bias"]), h2w: T(h["head.4.weight"]), h2b: T(h["head.4.bias"]) };
      this.names = ["Hybrid CNN+Features", "Char-CNN", "Char-BiLSTM", "MLP", "Gradient Boosting", "Logistic Regression"];
      this.family = { "Hybrid CNN+Features": "Hybrid DL", "Char-CNN": "Learned DL", "Char-BiLSTM": "Learned DL",
        "MLP": "Handcrafted DL", "Gradient Boosting": "Handcrafted ML", "Logistic Regression": "Handcrafted ML" };
    }
    inputs(rawUrl) {
      const canon = canonicalize(rawUrl);
      const f = extractFeatures("http://" + canon);
      const h = hostname(canon);
      f.domain_popularity = domainPopularity(h);
      f.free_hosting = freeHosting(h);
      const x = this.sel.map((k) => f[k]);
      const z = x.map((v, i) => Math.fround(Math.min(6, Math.max(-6, (v - this.sc.mean[i]) / this.sc.scale[i]))));
      return { canon, x, z, ids: encodeChars(canon), feats: f };
    }
    pGB(x) {
      const g = this.gb; let raw = g.base;
      for (const r of g.roots) { let n = r; while (!g.leaf[n]) n = x[g.feat[n]] <= g.thr[n] ? g.left[n] : g.right[n]; raw += g.value[n]; }
      return sig(raw);
    }
    pLR(x) { const p = this.lrp; let s = p.intercept; for (let i = 0; i < x.length; i++) s += ((x[i] - p.mean[i]) / p.scale[i]) * p.coef[i]; return sig(s); }
    pMLP(z) {
      const m = this.mlp;
      let h = relu(bn(linear(m.l0[0], m.l0[1], z, 128, z.length), ...m.bn1));
      h = relu(bn(linear(m.l4[0], m.l4[1], h, 64, 128), ...m.bn5));
      return sig(linear(m.l8[0], m.l8[1], h, 1, 64)[0]);
    }
    cnnHead(pooled) { const c = this.cnn; return sig(linear(c.h2w, c.h2b, relu(linear(c.h1w, c.h1b, pooled, 128, 384)), 1, 128)[0]); }
    fbranch(z) { const h = this.hyb; return relu(bn(linear(h.fw, h.fb, z, 64, z.length), ...h.fbn)); }
    hybHead(pooled, fb) {
      const h = this.hyb, v = new Float64Array(448); v.set(pooled, 0); v.set(fb, 384);
      return sig(linear(h.h2w, h.h2b, relu(linear(h.h1w, h.h1b, v, 128, 448)), 1, 128)[0]);
    }
    pCNN(ids) { return this.cnnHead(cnnPool(this.cnn.enc, cnnActs(this.cnn.enc, ids))); }
    pHybrid(ids, z) { return this.hybHead(cnnPool(this.hyb.enc, cnnActs(this.hyb.enc, ids)), this.fbranch(z)); }
    pLSTM(ids) {
      const m = this.lstm, H = m.H, E = 48, L = ids.length, G = 4 * H;
      if (L === 0) { const v = new Float64Array(4 * H); v.fill(-1e4, 0, 2 * H); return sig(linear(m.h2w, m.h2b, relu(linear(m.h1w, m.h1b, v, 128, 4 * H)), 1, 128)[0]); }
      const out = [new Float64Array(L * H), new Float64Array(L * H)];
      m.dirs.forEach((d, di) => {
        let h = new Float64Array(H), c = new Float64Array(H);
        for (let s = 0; s < L; s++) {
          const t = di === 0 ? s : L - 1 - s, eo = ids[t] * E, g = new Float64Array(G);
          for (let r = 0; r < G; r++) {
            let v = d.b[r]; const wi = r * E, wh = r * H;
            for (let e = 0; e < E; e++) v += d.wih[wi + e] * m.emb[eo + e];
            for (let k = 0; k < H; k++) v += d.whh[wh + k] * h[k];
            g[r] = v;
          }
          const nh = new Float64Array(H);
          for (let k = 0; k < H; k++) {
            const ig = sig(g[k]), fg = sig(g[H + k]), gg = Math.tanh(g[2 * H + k]), og = sig(g[3 * H + k]);
            c[k] = fg * c[k] + ig * gg; nh[k] = og * Math.tanh(c[k]);
          }
          h = nh; out[di].set(h, t * H);
        }
      });
      const pooled = new Float64Array(4 * H);
      for (let di = 0; di < 2; di++) for (let k = 0; k < H; k++) {
        let mx = -Infinity, sum = 0;
        for (let t = 0; t < L; t++) { const v = out[di][t * H + k]; if (v > mx) mx = v; sum += v; }
        pooled[di * H + k] = mx; pooled[2 * H + di * H + k] = sum / L;
      }
      return sig(linear(m.h2w, m.h2b, relu(linear(m.h1w, m.h1b, pooled, 128, 4 * H)), 1, 128)[0]);
    }
    predictAll(rawUrl) {
      const I = this.inputs(rawUrl);
      return { canonical: I.canon, input: I, probs: {
        "Hybrid CNN+Features": this.pHybrid(I.ids, I.z), "Char-CNN": this.pCNN(I.ids), "Char-BiLSTM": this.pLSTM(I.ids),
        "MLP": this.pMLP(I.z), "Gradient Boosting": this.pGB(I.x), "Logistic Regression": this.pLR(I.x) } };
    }
    // occlusion saliency (explain.char_occlusion) — fast incremental version for CNN-based models
    saliency(rawUrl, model) {
      const I = this.inputs(rawUrl);
      const useHyb = model === "Hybrid CNN+Features";
      const enc = useHyb ? this.hyb.enc : this.cnn.enc;
      const fb = useHyb ? this.fbranch(I.z) : null;
      const head = (p) => (useHyb ? this.hybHead(p, fb) : this.cnnHead(p));
      const ids = I.ids, L = ids.length;
      if (!L) return { canon: I.canon, base: 0, scores: [], model: useHyb ? model : "Char-CNN" };
      const acts = cnnActs(enc, ids), base = head(cnnPool(enc, acts));
      const pre = acts.A.map((a) => { const r = new Float64Array(a.length); for (let f = 0; f < enc.F; f++) { let m = -Infinity; for (let t = 0; t < L; t++) { m = Math.max(m, a[f * L + t]); r[f * L + t] = m; } } return r; });
      const suf = acts.A.map((a) => { const r = new Float64Array(a.length); for (let f = 0; f < enc.F; f++) { let m = -Infinity; for (let t = L - 1; t >= 0; t--) { m = Math.max(m, a[f * L + t]); r[f * L + t] = m; } } return r; });
      const unk = enc.emb.subarray(UNK * enc.E, UNK * enc.E + enc.E);
      const drop = new Float64Array(L);
      for (let i = 0; i < L; i++) {
        const lo = Math.max(0, i - 1), hi = Math.min(L - 1, i + 1);
        const X = acts.X.slice();
        for (let t = lo; t <= hi; t++) X.set(unk, t * enc.E);
        const pooled = new Float64Array(enc.F * 3);
        for (let c = 0; c < 3; c++) {
          const pad = enc.convs[c].k >> 1, a0 = Math.max(0, lo - pad), b0 = Math.min(L - 1, hi + pad);
          for (let f = 0; f < enc.F; f++) {
            let m = -Infinity;
            if (a0 > 0) m = pre[c][f * L + a0 - 1];
            if (b0 < L - 1) m = Math.max(m, suf[c][f * L + b0 + 1]);
            for (let t = a0; t <= b0; t++) m = Math.max(m, convAt(enc, c, X, L, f, t));
            pooled[c * enc.F + f] = m;
          }
        }
        drop[i] = base - head(pooled);
      }
      const scores = new Float64Array(L), cnt = new Float64Array(L);
      for (let i = 0; i < L; i++) for (let t = Math.max(0, i - 1); t <= Math.min(L - 1, i + 1); t++) { scores[t] += drop[i]; cnt[t] += 1; }
      for (let t = 0; t < L; t++) scores[t] /= Math.max(cnt[t], 1);
      return { canon: I.canon, base, scores: Array.from(scores), model: useHyb ? model : "Char-CNN" };
    }
    threshold(model, mode) { return mode === "low_fpr" ? (this.meta.thresholds_1pct_fpr[model] ?? 0.5) : 0.5; }
  }
  const riskBand = (p) => (p >= 0.7 ? "HIGH" : p >= 0.3 ? "MEDIUM" : "LOW");

  return { FEATURE_NAMES, canonicalize, hostname, encodeChars, extractFeatures, redFlags, Models, riskBand, urlparse,
    registrableDomain, domainPopularity, setReputation };
});
