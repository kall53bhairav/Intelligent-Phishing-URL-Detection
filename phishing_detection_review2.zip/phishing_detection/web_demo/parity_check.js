// Node side of parity_test.py
const fs = require("fs");
const PC = require("./phishcore.js");
const exp = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const M = new PC.Models(JSON.parse(fs.readFileSync(process.argv[3], "utf8")));
let canonBad = 0, featBad = [], flagBad = [], maxd = {};
const t0 = Date.now();
exp.urls.forEach((u, i) => {
  if (PC.canonicalize(u) !== exp.canonical[i]) canonBad++;
  const f = PC.extractFeatures(u);
  PC.FEATURE_NAMES.forEach((k, j) => { if (Math.abs(f[k] - exp.features[i][j]) > 1e-9) featBad.push([u.slice(0, 60), k, f[k], exp.features[i][j]]); });
  if (JSON.stringify(PC.redFlags(u)) !== JSON.stringify(exp.flags[i])) flagBad.push([u.slice(0, 60), JSON.stringify(PC.redFlags(u)), JSON.stringify(exp.flags[i])]);
  const r = M.predictAll(u).probs;
  for (const [m, p] of Object.entries(r)) { const d = Math.abs(p - exp.probs[m][i]); if (!(m in maxd) || d > maxd[m][0]) maxd[m] = [d, u.slice(0, 50)]; }
});
const ms = (Date.now() - t0) / exp.urls.length;
let salMax = 0;
for (const [key, v] of Object.entries(exp.sal)) {
  const [m, u] = [key.split("|")[0], key.slice(key.indexOf("|") + 1)];
  const s = M.saliency(u, m);
  salMax = Math.max(salMax, Math.abs(s.base - v.base), ...s.scores.map((x, i) => Math.abs(x - v.scores[i])));
}
console.log(`URLs: ${exp.urls.length} | canonical mismatches: ${canonBad} | feature mismatches: ${featBad.length} | red-flag mismatches: ${flagBad.length}`);
console.log("max |P_js - P_python| per model:");
for (const [m, [d, u]] of Object.entries(maxd)) console.log(`  ${m.padEnd(22)} ${d.toExponential(2)}   (worst: ${u})`);
console.log(`saliency max abs diff: ${salMax.toExponential(2)} | avg time per URL (all 6 models): ${ms.toFixed(1)} ms`);
const worst = Math.max(...Object.values(maxd).map((x) => x[0]));
fs.writeFileSync(require("path").join(__dirname, "parity_summary.txt"),
  `${exp.urls.length.toLocaleString("en-US")} URLs: identical features and signals, max probability difference ${worst < 1e-6 ? "< 10⁻⁶" : worst.toExponential(1)}`);
featBad.slice(0, 8).forEach((x) => console.log("  FEAT", JSON.stringify(x)));
flagBad.slice(0, 5).forEach((x) => console.log("  FLAG", JSON.stringify(x)));
