"""
build_web_demo.py — assembles the single-file browser demo web_demo/index.html
from app_template.html + phishcore.js + model_bundle.json + benchmark results.

    python web_demo/export_web_models.py   # after (re)training
    python web_demo/build_web_demo.py      # -> web_demo/index.html  (open it in any browser)
"""
import base64, io, json, os
import pandas as pd
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)

def img_uri(path):
    im = Image.open(path).convert("RGB"); im.thumbnail((1700, 1700))
    buf = io.BytesIO(); im.save(buf, "JPEG", quality=82, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

safe = lambda s: s.replace("</", "<\\/")
met = pd.read_csv(os.path.join(ROOT, "results", "r2_metrics.csv")).sort_values("f1", ascending=False)
cols = ["model", "family", "precision", "recall", "f1", "roc_auc", "pr_auc", "fpr", "fnr", "recall_at_1pct_fpr", "latency_ms"]
html = open(os.path.join(HERE, "app_template.html"), encoding="utf-8").read()
html = html.replace("/*__PHISHCORE__*/", open(os.path.join(HERE, "phishcore.js"), encoding="utf-8").read())
html = html.replace("__BUNDLE__", safe(open(os.path.join(HERE, "model_bundle.json")).read()))
html = html.replace("__METRICS__", safe(json.dumps(met[cols].round(4).to_dict(orient="records"))))
html = html.replace("__IMG_ROC__", img_uri(os.path.join(ROOT, "plots", "r2", "roc_pr_curves.png")))
html = html.replace("__IMG_THR__", img_uri(os.path.join(ROOT, "plots", "r2", "threshold_tradeoff.png")))
par = os.path.join(HERE, "parity_summary.txt")
html = html.replace("__PARITY__", open(par).read().strip() if os.path.exists(par) else "see parity_test.py")
out = os.path.join(HERE, "index.html")
open(out, "w", encoding="utf-8").write(html)
print(f"wrote {out} ({os.path.getsize(out)/1e6:.2f} MB)")
