"""
export_web_models.py
--------------------
Exports the trained Review-2 models (models/) into one JSON bundle that the
browser demo (web_demo/index.html) runs with plain JavaScript - no server,
no Python needed to *use* the demo.

    python web_demo/export_web_models.py      ->  web_demo/model_bundle.json
"""
import base64, json, os, sys
import numpy as np, joblib, torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
M = os.path.join(ROOT, "models")
b64 = lambda a, dt: base64.b64encode(np.ascontiguousarray(a, dtype=dt).tobytes()).decode()

def tensors(path, skip=()):
    sd = torch.load(path, map_location="cpu", weights_only=False)["state_dict"]
    return {k: {"shape": list(v.shape), "data": b64(v.numpy(), "<f4")}
            for k, v in sd.items() if v.dtype.is_floating_point and not any(k.startswith(s) for s in skip)}

meta = json.load(open(os.path.join(M, "meta.json")))
sc = joblib.load(os.path.join(M, "feature_scaler.joblib"))
lr = joblib.load(os.path.join(M, "ml_logistic_regression.joblib"))
gb = joblib.load(os.path.join(M, "ml_gradient_boosting.joblib")).named_steps["clf"]

feat, thr, left, right, leaf, val, roots = [], [], [], [], [], [], []
for (tree,) in gb._predictors:
    off = len(feat); roots.append(off)
    n = tree.nodes
    feat += n["feature_idx"].tolist(); thr += n["num_threshold"].tolist()
    left += (n["left"].astype(np.int64) + off).tolist(); right += (n["right"].astype(np.int64) + off).tolist()
    leaf += n["is_leaf"].tolist(); val += n["value"].tolist()

# reputation: public suffix rules + popularity levels (same files reputation.py reads)
sys.path.insert(0, ROOT)
from reputation import PSL_PATH, POP_PATH, _load_psl, _pop
normal, wild, exc = _load_psl()
pop = _pop()
by_level = {}
for k, v in pop.items():
    by_level.setdefault(str(v), []).append(k)
reputation = {"psl": {"normal": sorted(normal), "wild": sorted(wild), "exc": sorted(exc)},
              "pop": {lvl: "\n".join(sorted(keys)) for lvl, keys in by_level.items()}}

bundle = {
    "reputation": reputation,
    "meta": {k: meta[k] for k in ["selected_features", "hc_features", "best_ml", "thresholds_1pct_fpr", "test_metrics", "n_train", "n_test"]},
    "scaler": {"mean": sc.mean_.tolist(), "scale": sc.scale_.tolist()},
    "lr": {"mean": lr.named_steps["scaler"].mean_.tolist(), "scale": lr.named_steps["scaler"].scale_.tolist(),
           "coef": lr.named_steps["clf"].coef_[0].tolist(), "intercept": float(lr.named_steps["clf"].intercept_[0])},
    "gb": {"baseline": float(np.ravel(gb._baseline_prediction)[0]), "roots": roots,
           "feat": b64(feat, "<i2"), "thr": b64(thr, "<f8"), "left": b64(left, "<i4"),
           "right": b64(right, "<i4"), "leaf": b64(leaf, "u1"), "value": b64(val, "<f8")},
    "cnn": tensors(os.path.join(M, "dl_char_cnn.pt")),
    "bilstm": tensors(os.path.join(M, "dl_char_bilstm.pt")),
    "mlp": tensors(os.path.join(M, "dl_mlp.pt")),
    "hybrid": tensors(os.path.join(M, "dl_hybrid_cnnplusfeatures.pt"), skip=("cnn.head",)),
}
out = os.path.join(ROOT, "web_demo", "model_bundle.json")
json.dump(bundle, open(out, "w"))
print(f"wrote {out}  ({os.path.getsize(out)/1e6:.2f} MB, {len(feat)} GB nodes)")
