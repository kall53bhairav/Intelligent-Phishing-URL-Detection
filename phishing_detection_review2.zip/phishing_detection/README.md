# Intelligent Phishing URL Detection System

M.Tech Cyber Security, IIIT Sri City — Tushar Agarwal (OMCS25S00093) · Sumit Parvat (OMCS25S00088)

---

## Review 2 — handcrafted ML vs learned deep representations

**Panel requirements → where they are implemented**

| Requirement | Implementation |
|---|---|
| Develop an MLP, character-level CNN or LSTM | `dl_models.py`: `FeatureMLP`, `CharCNN`, `CharBiLSTM`, `HybridCNN` (PyTorch) |
| Compare handcrafted-feature ML vs learned-representation DL | `run_review2.py` (10 models, one split, CIs, McNemar, latency) + `learning_curve.py` |
| False-positive / false-negative analysis | `error_analysis.py` (+ `explain.py` for taxonomy and saliency) |
| Interface: user enters a URL, gets a phishing-risk prediction | `app.py` (Streamlit) and `predictor.py` (CLI / API) |

### Data (real-world, replaces the synthetic Review-1 set for evaluation)

`prepare_real_data.py` builds a balanced 200,000-URL benchmark from five public sources:

| Class | Source | URLs |
|---|---|---|
| phishing | PhiUSIIL (UCI, Prasad & Chandra 2024) | 50,000 |
| phishing | Phishing.Database ACTIVE list (still-online phishing, recent campaigns) | 50,000 |
| legitimate | PhiUSIIL home pages | 35,000 |
| legitimate | Kaggle Malicious-URLs, benign class (deep URLs with real paths) | 35,000 |
| legitimate | Chrome UX Report top-1M origins (sites people use today) | 30,000 |

* **Shortcut audit** — on PhiUSIIL as published, a logistic regression on 4 formatting flags
  (https, www, has path, has scheme) reaches **F1 = 0.995** without reading the domain.
  Every URL is therefore canonicalised (scheme and `www.` removed, host lower-cased); the same flags
  then give F1 = 0.512 (accuracy 58.8%, near chance).
* De-duplication, ≤ 3 URLs per hostname, and a **hostname-disjoint** 70/10/20 split
  (139,999 / 20,000 / 40,001) — no host appears in two splits.
* The live OpenPhish feed and the 54 familiar sites in `data/sanity/` are excluded from every split.

### Accuracy upgrade (v2)

Version 1 (2 sources, 160 chars, no reputation) flagged **27 of 54** everyday sites (Gmail, SBI, IRCTC, GitHub login…)
as phishing. Version 2 adds fresher phishing data, modern legitimate sites, 256-character inputs and two
reputation features (`reputation.py`):

* `domain_popularity` (0–5): rank of the site in Google's Chrome UX Report top-100k, looked up on the exact host
  and on its registrable domain via the Public Suffix List **including private suffixes** (so `evil.web.app`
  does not inherit `web.app`'s popularity);
* `free_hosting` (0/1): host on a platform where anyone can publish (weebly, firebaseapp, pages.dev, …).

`sanity_check.py` (54 familiar sites + 271 live OpenPhish URLs, none in training), Hybrid model:
false alarms **27 → 2** of 54, live phishing caught **85% → 90%**.
`ablation_reputation.py`: Gradient Boosting F1 0.789 → 0.809, familiar false alarms 31 → 3.
Char-only models (no reputation input) still flag 30–32 of 54, which is why the Hybrid is the deployed default.

### Results (test set, 40,001 URLs with unseen hostnames, threshold 0.5)

| Model | Family | Precision | Recall | F1 | ROC-AUC | FPR | FNR | Recall@1%FPR | ms/URL |
|---|---|---|---|---|---|---|---|---|---|
| Char n-gram TF-IDF + LR | Reference | 0.919 | 0.847 | 0.882 | 0.948 | 0.075 | 0.153 | 0.707 | 0.61 |
| Hybrid CNN+Features | Hybrid DL | 0.921 | 0.831 | 0.874 | 0.947 | 0.071 | 0.169 | 0.694 | 3.13 |
| Char-BiLSTM | Learned + DL | 0.938 | 0.817 | 0.873 | 0.945 | 0.054 | 0.183 | 0.686 | 1.25 |
| Char-CNN | Learned + DL | 0.941 | 0.812 | 0.872 | 0.945 | 0.051 | 0.188 | 0.698 | 0.58 |
| Gradient Boosting | Handcrafted + ML | 0.865 | 0.759 | 0.809 | 0.897 | 0.118 | 0.241 | 0.503 | 4.93 |
| MLP | Handcrafted + DL | 0.859 | 0.758 | 0.806 | 0.892 | 0.124 | 0.242 | 0.480 | 3.13 |
| Random Forest | Handcrafted + ML | 0.847 | 0.762 | 0.802 | 0.877 | 0.138 | 0.238 | 0.413 | 18.22 |
| SVM (RBF) | Handcrafted + ML | 0.837 | 0.769 | 0.802 | 0.873 | 0.149 | 0.231 | 0.290 | 4.15 |
| Decision Tree | Handcrafted + ML | 0.849 | 0.729 | 0.785 | 0.870 | 0.130 | 0.271 | 0.333 | 2.63 |
| Logistic Regression | Handcrafted + ML | 0.820 | 0.649 | 0.725 | 0.825 | 0.142 | 0.351 | 0.162 | 2.73 |

* Learned character representations beat handcrafted features: **Char-BiLSTM F1 0.873 vs Gradient Boosting 0.809**
  (McNemar p < 1e-10). An MLP on the handcrafted features does not close the gap, so the
  representation — not depth — is what matters.
* Char-BiLSTM misses **1,144 fewer phishing URLs** than Gradient Boosting at threshold 0.5.
* Char-BiLSTM recovers 1,899 of Gradient Boosting's missed phish; 2,915 fool both
  families (mostly clean-looking short domains).

Full analysis outputs: `results/r2_*.csv|json`, figures in `plots/r2/`.

### Run Review 2

```bash
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

# optional – rebuild everything (data/real_urls.csv and models/ are already included)
./venv/bin/python reputation.py            # popularity table (downloads the CrUX list)
./venv/bin/python prepare_real_data.py      # raw sources auto-download into data/raw/
./venv/bin/python run_review2.py            # ~2 h on a 2-core CPU (BiLSTM is the slow part)
./venv/bin/python sanity_check.py
./venv/bin/python learning_curve.py
./venv/bin/python error_analysis.py
./venv/bin/python ablation_reputation.py

# interface
./venv/bin/streamlit run app.py             # http://localhost:8501
./venv/bin/python predictor.py "http://secure-login.example-verify.xyz/account"
```

### Browser demo (no install)

`web_demo/index.html` is a single-file build of the interface: the same trained weights run in JavaScript,
so the demo needs no Python and no server — open it in Chrome / Edge / Safari.
`export_web_models.py` → `model_bundle.json`; `phishcore.js` ports canonicalisation, the 29 features, red flags,
saliency and all six models; `parity_test.py` checks it against Python; `build_web_demo.py` assembles the page.

### Review-2 files

| File | Purpose |
|---|---|
| `url_utils.py` | canonicalisation + character encoding shared by training and inference |
| `reputation.py` | domain popularity (CrUX top-100k + Public Suffix List) and free-hosting flag |
| `sanity_check.py` · `ablation_reputation.py` | real-world check (familiar sites, live feed) · with/without reputation |
| `prepare_real_data.py` | builds the real-world composite, shortcut audit, hostname-disjoint split |
| `dl_models.py` | MLP, Char-CNN, Char-BiLSTM, Hybrid; bucketed training loop, early stopping |
| `run_review2.py` | trains and evaluates all 10 models; saves metrics, predictions, `models/` |
| `learning_curve.py` | F1 vs training-set size per family |
| `error_analysis.py` | confusion, operating points, overlap, taxonomy, by source / length, saliency |
| `explain.py` | occlusion saliency, rule-based red flags, error categories |
| `predictor.py` | loads `models/`, scores URLs (also a CLI) |
| `app.py` | Streamlit interface (Review 2); `app_review1.py` is the original Review-1 UI |

---

## Review 1 (unchanged)

Predicts whether a URL is **legitimate** or **phishing** using lexical,
structural, and host-based characteristics. Trains and compares four classifiers
and evaluates them with Precision, Recall, F1-score, and ROC-AUC.

### Pipeline

```
generate_dataset.py -> features.py -> eda.py -> feature_selection.py -> models.py
                                     (orchestrated by main.py)
```

1. **Data** (`generate_dataset.py`) — builds a balanced, *realistic* dataset of
   5000 URLs (2500 legit / 2500 phishing). Includes deliberate class overlap:
   "hard" legit URLs that look suspicious (long paths, digits, query strings) and
   "stealth" phishing URLs that mimic clean HTTPS domains — so the task is not
   trivially separable. Replace with your own `[url,label]` CSV via `--data`.

2. **Features** (`features.py`) — extracts **28 features** in three families:
   - *Lexical / character-level*: url_length, num_dots, num_hyphens, num_at,
     num_question, num_equals, num_underscore, num_percent, num_ampersand,
     num_digits, num_special, digit_ratio, special_ratio, **url_entropy**
     (Shannon entropy).
   - *Structural*: num_subdomains, path_length, num_path_segments, query_length,
     num_query_params, has_port.
   - *Host-based / protocol*: uses_https, has_ip (IP-literal host),
     host_length, host_digit_ratio, tld_length, suspicious_tld, has_punycode
     (IDN homograph), num_keywords (phishing lexicon hits).

3. **EDA** (`eda.py`) — class balance, per-class feature distributions,
   correlation heatmap, boxplots, and a mean-difference table.

4. **Feature selection** (`feature_selection.py`) — correlation pruning
   (drop |corr| > 0.90), univariate ANOVA-F, and Random-Forest importance;
   combined normalized score picks the final subset.

5. **Models** (`models.py`) — Logistic Regression, Decision Tree, Random Forest,
   SVM (RBF, probability-calibrated). LR and SVM are scaled with StandardScaler.

6. **Evaluation** — Precision, Recall, F1, ROC-AUC on a stratified 20% test set,
   plus 5-fold cross-validated F1. Saves ROC curves, a metric comparison bar
   chart, and confusion matrices.

### Run

```bash
python3 -m venv venv
./venv/bin/pip install scikit-learn pandas numpy matplotlib seaborn streamlit
./venv/bin/python main.py                    # synthetic data (CLI pipeline)
./venv/bin/python main.py --data your.csv     # your own [url,label] csv
```

### Web UI (interactive)

A Streamlit app (`app.py`) lets you paste any URL and see a live
legit/phishing verdict with a probability score, a feature breakdown, and the
model metrics — with minimal animations.

```bash
./venv/bin/streamlit run app_review1.py
```

Then open http://localhost:8501. The app trains the model once (cached) and
reuses the exact feature-extraction and modeling pipeline as the CLI.

> College project — Roll No OMCS25S00093 · Group member Sumit Parvat (OMCS25S00088)

### Outputs

- `plots/` — class_balance, feature_distributions, correlation_heatmap,
  boxplots, feature_importance, roc_curves, model_comparison, confusion_matrices
- `results/metrics.csv` — full metric table

### Latest results (test set, n=1000)

| Model               | Precision | Recall | F1     | ROC-AUC |
|---------------------|-----------|--------|--------|---------|
| Logistic Regression | 0.994     | 0.984  | 0.989  | 0.9996  |
| Decision Tree       | 0.996     | 0.990  | 0.993  | 0.9929  |
| Random Forest       | 0.994     | 0.994  | 0.994  | 0.9994  |
| SVM (RBF)           | 0.986     | 0.990  | 0.988  | 0.9996  |

Best model by F1: **Random Forest** (F1 = 0.994, ROC-AUC = 0.9994).

> Note: metrics are strong because the dataset is synthetic. On real-world
> corpora (PhishTank, OpenPhish, UCI) expect lower but still competitive numbers.
> The feature extractor and modeling code work unchanged on real `[url,label]` data.
