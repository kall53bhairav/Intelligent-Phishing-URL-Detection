"""Shared matplotlib style + palette so every Review-2 figure looks consistent."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

INK = "#0F1B2D"
SLATE = "#475569"
GRID = "#E2E8F0"
PHISH = "#E63946"      # phishing / risk
SAFE = "#2A9D8F"       # legitimate / safe
AMBER = "#E9A23B"
FAMILY_COLORS = {
    "Handcrafted + ML": "#3D5A80",
    "Handcrafted + DL": "#98A6C4",
    "Learned + DL": "#2A9D8F",
    "Hybrid DL": "#E9A23B",
    "Reference": "#A0AEC0",
    "Ensemble": "#7B2CBF",
}


def apply_style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 11,
        "axes.edgecolor": SLATE, "axes.labelcolor": INK, "axes.titleweight": "bold",
        "axes.titlesize": 13, "axes.titlecolor": INK, "axes.spines.top": False,
        "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
        "grid.linewidth": 0.8, "xtick.color": SLATE, "ytick.color": SLATE,
        "legend.frameon": False, "figure.dpi": 110, "savefig.dpi": 200,
        "savefig.bbox": "tight", "figure.facecolor": "white",
    })
