"""
error_analysis.py
-----------------
False-positive / false-negative analysis for Review 2 (run after run_review2.py).

  FP = legitimate URL flagged as phishing  (user friction, alert fatigue)
  FN = phishing URL let through            (security miss -- the costly error)

Analyses
  1. Confusion matrices: best handcrafted ML vs best learned DL vs hybrid
     (+ a late-fusion ensemble of the two families)
  2. Threshold trade-off (FPR / FNR vs threshold) and three operating points:
     default 0.5, 1 % FPR (threshold chosen on VALIDATION), equal-error-rate
  3. Error overlap: which mistakes are shared, ML-only, DL-only
  4. Error taxonomy: why each FP / FN happened (rule-based categories)
  5. Error rate by data source and by URL length
  6. Handcrafted-feature profile of TP / FN / TN / FP
  7. Most-confident mistakes + character-level saliency of examples
"""
import json
import os

import numpy as np
import pandas as pd

from explain import char_occlusion, error_category
from features import FEATURE_NAMES, extract_features
from plot_style import AMBER, FAMILY_COLORS, INK, PHISH, SAFE, SLATE, apply_style
from run_review2 import FAMILY, SLUG

import matplotlib.pyplot as plt
from sklearn.metrics import (average_precision_score, f1_score, precision_recall_curve,
                             roc_auc_score, roc_curve)

R, P = "results", "plots/r2"
os.makedirs(P, exist_ok=True)
apply_style()


def rates(y, p, thr):
    pred = p >= thr
    tp = int((pred & (y == 1)).sum()); fn = int((~pred & (y == 1)).sum())
    fp = int((pred & (y == 0)).sum()); tn = int((~pred & (y == 0)).sum())
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn)
    return {"threshold": thr, "tp": tp, "fp": fp, "tn": tn, "fn": fn,
            "fpr": fp / (fp + tn), "fnr": fn / (fn + tp), "precision": prec,
            "recall": rec, "f1": 2 * prec * rec / (prec + rec) if prec + rec else 0.0}


def thr_for_fpr(yv, pv, target=0.01):
    neg = np.sort(pv[yv == 0])
    k = int(np.floor(target * len(neg)))
    return float(neg[-k - 1]) + 1e-9


def eer_threshold(yv, pv):
    ts = np.linspace(0.001, 0.999, 999)
    d = [abs(rates(yv, pv, t)["fpr"] - rates(yv, pv, t)["fnr"]) for t in ts]
    return float(ts[int(np.argmin(d))])


def main():
    met = pd.read_csv(f"{R}/r2_metrics.csv", index_col=0)
    te = pd.read_csv(f"{R}/r2_test_predictions.csv")
    va = pd.read_csv(f"{R}/r2_val_predictions.csv")
    y, yv = te.label.values, va.label.values
    col = lambda n: f"p_{SLUG[n]}"

    ml_names = met.index[met.family == "Handcrafted + ML"]
    best_ml = met.loc[ml_names, "f1"].idxmax()
    best_dl = met.loc[met.family == "Learned + DL", "f1"].idxmax()
    hyb = "Hybrid CNN+Features"
    ens = f"Ensemble (avg {best_ml} + {best_dl})"
    te[col(best_ml) + "_ens"] = 0
    pe, pve = ((te[col(best_ml)] + te[col(best_dl)]) / 2).values, \
              ((va[col(best_ml)] + va[col(best_dl)]) / 2).values
    probs = {best_ml: te[col(best_ml)].values, best_dl: te[col(best_dl)].values,
             hyb: te[col(hyb)].values, ens: pe}
    vprobs = {best_ml: va[col(best_ml)].values, best_dl: va[col(best_dl)].values,
              hyb: va[col(hyb)].values, ens: pve}
    print(f"best handcrafted ML = {best_ml} | best learned DL = {best_dl}")

    # ---- 1) confusion + ensemble metrics -----------------------------------
    conf = []
    for n, p in probs.items():
        r = rates(y, p, 0.5)
        conf.append({"model": n, **r, "roc_auc": roc_auc_score(y, p),
                     "pr_auc": average_precision_score(y, p)})
    conf = pd.DataFrame(conf)
    conf.to_csv(f"{R}/r2_confusion.csv", index=False)

    # ---- 2) operating points -----------------------------------------------
    ops = []
    for n in probs:
        for setting, t in [("Default (0.50)", 0.5),
                           ("Low-FPR (1% on val)", thr_for_fpr(yv, vprobs[n])),
                           ("Equal error rate", eer_threshold(yv, vprobs[n]))]:
            ops.append({"model": n, "setting": setting, **rates(y, probs[n], t)})
    ops = pd.DataFrame(ops)
    ops.to_csv(f"{R}/r2_operating_points.csv", index=False)

    ts = np.linspace(0.01, 0.99, 99)
    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    for n, c, ls in [(best_ml, FAMILY_COLORS["Handcrafted + ML"], "-"),
                     (best_dl, FAMILY_COLORS["Learned + DL"], "-")]:
        rr = [rates(y, probs[n], t) for t in ts]
        ax.plot(ts, [r["fpr"] * 100 for r in rr], color=c, lw=2.4, ls="--", label=f"{n} - FPR")
        ax.plot(ts, [r["fnr"] * 100 for r in rr], color=c, lw=2.4, ls="-", label=f"{n} - FNR")
    ax.axvline(0.5, color=SLATE, lw=1, ls=":")
    ax.text(0.505, ax.get_ylim()[1] * 0.92, "default 0.5", color=SLATE, fontsize=9)
    ax.set_xlabel("decision threshold on P(phishing)")
    ax.set_ylabel("error rate (%)")
    ax.set_title("Moving the threshold trades false positives (dashed) for false negatives (solid)", fontsize=12)
    ax.legend(fontsize=9.5, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.16))
    fig.savefig(f"{P}/threshold_tradeoff.png")
    plt.close(fig)

    # ---- 3) error overlap ----------------------------------------------------
    pm, pd_ = probs[best_ml] >= 0.5, probs[best_dl] >= 0.5
    ov = []
    for etype, cls, wrong in [("False negatives (missed phishing)", 1, lambda p: ~p),
                              ("False positives (legit flagged)", 0, lambda p: p)]:
        msk = y == cls
        em, ed = wrong(pm) & msk, wrong(pd_) & msk
        ov.append({"error_type": etype, "both": int((em & ed).sum()),
                   "ml_only": int((em & ~ed).sum()), "dl_only": int((~em & ed).sum())})
    ov = pd.DataFrame(ov)
    ov.to_csv(f"{R}/r2_error_overlap.csv", index=False)

    # ---- 4) taxonomy -----------------------------------------------------------
    te["err_cat"] = [error_category(u, l) for u, l in zip(te.url, te.label)]
    tax = []
    for n in [best_ml, best_dl]:
        pr = probs[n] >= 0.5
        for etype, cls, wrong in [("FN", 1, ~pr), ("FP", 0, pr)]:
            e = te[wrong & (y == cls)]
            vc = e["err_cat"].value_counts()
            for c, k in vc.items():
                tax.append({"model": n, "error": etype, "category": c, "count": int(k),
                            "share": k / len(e)})
    tax = pd.DataFrame(tax)
    tax.to_csv(f"{R}/r2_error_taxonomy.csv", index=False)

    # base rate of each category in the whole class (to show over-representation)
    base = (te.groupby(["label", "err_cat"]).size() / te.groupby("label").size()).rename("base_share")
    base.reset_index().to_csv(f"{R}/r2_category_base_rates.csv", index=False)

    # ---- 5a) by source -------------------------------------------------------
    src = []
    for n in list(probs):
        pr = probs[n] >= 0.5
        for s, g in te.groupby("source"):
            idx = g.index
            if g.label.iloc[0] == 1:
                er, kind = float((~pr[idx]).mean()), "FNR"
            else:
                er, kind = float(pr[idx].mean()), "FPR"
            src.append({"model": n, "source": s, "metric": kind, "rate": er, "n": len(g)})
    pd.DataFrame(src).to_csv(f"{R}/r2_error_by_source.csv", index=False)

    # ---- 5b) by length ---------------------------------------------------------
    L = te.url.str.len()
    bins = [0, 15, 25, 40, 80, 10000]
    labels = ["<=15", "16-25", "26-40", "41-80", ">80"]
    te["len_bucket"] = pd.cut(L, bins=bins, labels=labels)
    lb = []
    for n in [best_ml, best_dl, hyb]:
        pr = probs[n] >= 0.5
        for b in labels:
            g = te.len_bucket == b
            lg, ph = g & (y == 0), g & (y == 1)
            lb.append({"bucket": b, "model": n, "fpr": float(pr[lg].mean()),
                       "fnr": float((~pr[ph]).mean()), "n_legit": int(lg.sum()),
                       "n_phish": int(ph.sum())})
    pd.DataFrame(lb).to_csv(f"{R}/r2_error_by_length.csv", index=False)

    # ---- 6) feature profile of outcomes (best ML) ------------------------------
    F = pd.DataFrame([extract_features("http://" + u) for u in te.url], columns=FEATURE_NAMES)
    pr = probs[best_ml] >= 0.5
    outcome = np.where(y == 1, np.where(pr, "TP", "FN"), np.where(pr, "FP", "TN"))
    keyf = ["url_length", "host_length", "num_subdomains", "path_length", "num_digits",
            "num_hyphens", "url_entropy", "suspicious_tld", "num_keywords"]
    prof = F[keyf].groupby(outcome).mean().loc[["TP", "FN", "TN", "FP"]]
    prof.to_csv(f"{R}/r2_feature_profile.csv")

    # ---- 7) confident mistakes + disagreements ---------------------------------
    rows = []
    for n in [best_ml, best_dl]:
        p = probs[n]
        for etype, cls, order in [("FN", 1, 1), ("FP", 0, -1)]:
            m = (y == cls) & ((p >= 0.5) if cls == 0 else (p < 0.5))
            e = te[m].assign(prob=p[m]).sort_values("prob", ascending=(order == 1)).head(15)
            for _, r in e.iterrows():
                rows.append({"model": n, "error": etype, "url": r.url, "source": r.source,
                             "prob": r.prob, "category": r.err_cat})
    pd.DataFrame(rows).to_csv(f"{R}/r2_top_errors.csv", index=False)

    dis = te.assign(p_ml=probs[best_ml], p_dl=probs[best_dl])
    dl_catch = dis[(y == 1) & (dis.p_ml < 0.5) & (dis.p_dl >= 0.5)].sort_values("p_dl", ascending=False)
    ml_catch = dis[(y == 1) & (dis.p_dl < 0.5) & (dis.p_ml >= 0.5)].sort_values("p_ml", ascending=False)
    pd.concat([dl_catch.head(25).assign(who="DL catches, ML misses"),
               ml_catch.head(25).assign(who="ML catches, DL misses")])[
        ["who", "url", "source", "p_ml", "p_dl", "err_cat"]].to_csv(f"{R}/r2_disagreements.csv", index=False)

    # ---- ROC + PR for all models ---------------------------------------------
    allm = met.sort_values("f1", ascending=False).index.tolist()
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.2))
    for n in allm:
        p = te[col(n)].values
        c = FAMILY_COLORS[met.loc[n, "family"]]
        lw = 2.6 if n in (best_ml, best_dl, hyb) else 1.2
        a = 1.0 if n in (best_ml, best_dl, hyb) else 0.55
        fpr, tpr, _ = roc_curve(y, p)
        axes[0].plot(fpr, tpr, color=c, lw=lw, alpha=a, label=f"{n} ({roc_auc_score(y, p):.3f})")
        pr_, rc_, _ = precision_recall_curve(y, p)
        axes[1].plot(rc_, pr_, color=c, lw=lw, alpha=a, label=f"{n} ({average_precision_score(y, p):.3f})")
    axes[0].plot([0, 1], [0, 1], color=SLATE, ls=":", lw=1)
    axes[0].set(xlabel="False-positive rate", ylabel="True-positive rate", title="ROC curves (AUC)")
    axes[1].set(xlabel="Recall", ylabel="Precision", title="Precision-Recall curves (AP)", ylim=(0.45, 1.01))
    for ax in axes:
        ax.legend(fontsize=7.6, loc="lower right" if ax is axes[0] else "lower left")
    fig.tight_layout()
    fig.savefig(f"{P}/roc_pr_curves.png")
    plt.close(fig)

    # ---- character saliency examples (Char-CNN) --------------------------------
    import torch  # noqa: F401
    from dl_models import load_dl, predict_proba
    cnn, _ = load_dl(f"models/dl_{SLUG['Char-CNN']}.pt")
    fn = lambda C: predict_proba(cnn, C, None)
    short = te[(te.url.str.len() >= 18) & (te.url.str.len() <= 46)].copy()
    short["p"] = te.loc[short.index, col("Char-CNN")]
    picks = []
    def take(mask, title, asc):
        cand = short[mask].sort_values("p", ascending=asc)
        if len(cand):
            r = cand.iloc[min(2, len(cand) - 1)]
            picks.append((title, r.url, r.label))
    take((short.label == 1) & short.url.str.contains("firebaseapp|godaddysites|web.app|weebly|ipfs"),
         "Caught: phishing on free hosting", False)
    take((short.label == 1) & short.url.str.contains("login|verify|secure|account|wallet|meta"),
         "Caught: credential-lure host", False)
    take((short.label == 1) & (short.p < 0.5), "Missed (FN): looks like a normal site", True)
    take((short.label == 0) & (short.p >= 0.5), "False alarm (FP): legit flagged", False)
    fig, axes = plt.subplots(len(picks), 1, figsize=(11, 1.25 * len(picks) + 0.4))
    for ax, (title, u, lab) in zip(np.atleast_1d(axes), picks):
        base, sc = char_occlusion(fn, u)
        m = max(1e-6, np.abs(sc).max())
        for i, (ch, s) in enumerate(zip(u, sc)):
            a = min(1, abs(s) / m)
            ax.add_patch(plt.Rectangle((i, 0), 1, 1, color=PHISH if s > 0 else SAFE, alpha=0.08 + 0.85 * a, lw=0))
            ax.text(i + 0.5, 0.5, ch, ha="center", va="center", family="DejaVu Sans Mono",
                    fontsize=11, color=INK)
        ax.set_xlim(0, 48); ax.set_ylim(0, 1); ax.axis("off")
        ax.set_title(f"{title}   |   P(phishing) = {base:.2f}   |   true label = "
                     f"{'phishing' if lab else 'legitimate'}", loc="left", fontsize=10.5, color=INK)
    fig.tight_layout()
    fig.savefig(f"{P}/char_saliency_examples.png")
    plt.close(fig)

    # ---- summary -----------------------------------------------------------------
    summary = {
        "best_ml": best_ml, "best_dl": best_dl, "hybrid": hyb, "ensemble": ens,
        "confusion": conf.set_index("model").round(4).to_dict(orient="index"),
        "overlap": ov.to_dict(orient="records"),
        "n_test": int(len(te)), "n_dl_catches_ml_misses": int(len(dl_catch)),
        "n_ml_catches_dl_misses": int(len(ml_catch)),
        "saliency_examples": [p[:2] for p in picks],
    }
    with open(f"{R}/r2_analysis_summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=str)

    print(conf.round(4).to_string(index=False))
    print("\noperating points\n", ops.round(4).to_string(index=False))
    print("\noverlap\n", ov.to_string(index=False))
    print("\ntaxonomy\n", tax.round(3).to_string(index=False))
    print("\nby source\n", pd.DataFrame(src).round(4).to_string(index=False))
    print("\nfeature profile\n", prof.round(2).to_string())
    print("\nDL catches / ML misses:", len(dl_catch), " ML catches / DL misses:", len(ml_catch))


if __name__ == "__main__":
    main()
