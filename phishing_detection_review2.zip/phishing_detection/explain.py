"""
explain.py
----------
Explanations shared by the error analysis and the web interface.

  char_occlusion()  - character-level saliency for the char-CNN / BiLSTM /
                      hybrid models: each 3-char window is masked (replaced by
                      the UNK token) and the drop in phishing probability is
                      attributed to those characters.
                      +ve score = the characters push the URL towards PHISHING.
  red_flags()       - human-readable rule signals derived from the URL
                      (IP host, '@' trick, suspicious TLD, lure keywords,
                      free-hosting platform, punycode, ...).
  error_category()  - taxonomy used for false-positive / false-negative analysis.
"""
import re

import numpy as np

from features import PHISH_KEYWORDS, SUSPICIOUS_TLDS, extract_features
from url_utils import MAX_LEN, UNK_IDX, encode_chars, hostname

# Platforms where anyone can publish a page under the provider's domain.
FREE_HOSTING = (
    "firebaseapp.com", "web.app", "godaddysites.com", "weebly.com", "wixsite.com",
    "wix.com", "blogspot.com", "github.io", "netlify.app", "vercel.app",
    "pages.dev", "workers.dev", "repl.co", "replit.app", "glitch.me",
    "herokuapp.com", "azurewebsites.net", "cloudfront.net", "appspot.com",
    "ipfs.io", "cloudflare-ipfs.com", "dweb.link", "000webhostapp.com",
    "sharepoint.com", "sites.google.com", "wordpress.com", "square.site",
    "webflow.io", "mystrikingly.com", "surge.sh", "r2.dev", "amazonaws.com",
    "onrender.com", "translate.goog", "framer.app", "framer.website",
    "carrd.co", "gitbook.io", "my.site.com", "ngrok.io", "ngrok-free.app",
    "hostingersite.com", "jimdosite.com", "webcindario.com", "yolasite.com",
    "site123.me", "business.site", "ukit.me", "tilda.ws", "temp.domains",
    "ipfs.w3s.link", "nftstorage.link", "fleek.co", "on.fleek.co", "glide.page",
)
BRANDS = ("paypal", "apple", "microsoft", "office", "outlook", "amazon", "netflix",
          "google", "facebook", "instagram", "whatsapp", "metamask", "coinbase",
          "binance", "bank", "chase", "wellsfargo", "dhl", "fedex", "usps", "ups",
          "adobe", "dropbox", "docusign", "linkedin", "steam", "roblox", "att",
          "verizon", "irs", "gov", "wallet", "ledger", "trezor", "crypto", "nft",
          "auth", "sso", "owa", "webmail", "mail")
SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd",
              "cutt.ly", "rb.gy", "shorturl.at", "rebrand.ly", "t.ly", "s.id")


def is_free_hosting(host):
    return any(host == d or host.endswith("." + d) for d in FREE_HOSTING) or "ipfs" in host


# --------------------------------------------------------------------------- #
def char_occlusion(predict_fn, url, window=3):
    """predict_fn(list_of_char_matrices) -> probs.  Returns (base_prob, scores[len])."""
    u = str(url)[:MAX_LEN]
    C = encode_chars([u])
    L = len(u)
    if L == 0:
        return 0.0, np.zeros(0)
    variants = np.repeat(C, L, axis=0)
    half = window // 2
    for i in range(L):
        variants[i, max(0, i - half):min(L, i + half + 1)] = UNK_IDX
    probs = predict_fn(np.vstack([C, variants]))
    base, occl = float(probs[0]), probs[1:]
    drop = base - occl                             # +ve: window raised the risk
    scores = np.zeros(L)
    counts = np.zeros(L)
    for i in range(L):
        lo, hi = max(0, i - half), min(L, i + half + 1)
        scores[lo:hi] += drop[i]
        counts[lo:hi] += 1
    return base, scores / np.maximum(counts, 1)


def saliency_html(url, scores):
    """Inline-HTML heat-map: red = pushes towards phishing, green = towards legit."""
    u = str(url)[:MAX_LEN]
    m = max(1e-6, float(np.max(np.abs(scores)))) if len(scores) else 1.0
    spans = []
    for ch, s in zip(u, scores):
        a = min(1.0, abs(s) / m)
        col = f"rgba(230,57,70,{a:.2f})" if s > 0 else f"rgba(42,157,143,{a:.2f})"
        esc = {"<": "&lt;", ">": "&gt;", "&": "&amp;", " ": "&nbsp;"}.get(ch, ch)
        spans.append(f'<span style="background:{col};padding:2px 0;">{esc}</span>')
    return ('<div style="font-family:ui-monospace,Menlo,monospace;font-size:1.05rem;'
            'line-height:2.0;word-break:break-all;">' + "".join(spans) + "</div>")


# --------------------------------------------------------------------------- #
def red_flags(raw_url):
    """List of (signal, detail, severity) where severity in {'high','medium','info'}."""
    url = str(raw_url).strip()
    f = extract_features(url if "://" in url.split("?")[0] else "http://" + url)
    host = hostname(url)
    low = url.lower()
    flags = []
    if f["has_ip"]:
        flags.append(("IP-address host", host, "high"))
    if f["num_at"]:
        flags.append(("'@' in URL", "browser ignores everything before '@'", "high"))
    if f["has_punycode"]:
        flags.append(("Punycode (IDN) host", "possible homograph look-alike", "high"))
    if is_free_hosting(host):
        flags.append(("Free-hosting / cloud platform", host, "medium"))
    if any(host == s for s in SHORTENERS):
        flags.append(("URL shortener", "real destination hidden", "medium"))
    if f["suspicious_tld"]:
        flags.append(("Frequently-abused TLD", "." + host.split(".")[-1], "medium"))
    kw = sorted(k for k in PHISH_KEYWORDS if k in low)
    if kw:
        flags.append(("Credential-lure keywords", ", ".join(kw[:5]), "medium"))
    from reputation import domain_popularity, registrable_domain   # local import: avoids a cycle
    rd_label = "" if is_free_hosting(host) else (registrable_domain(host) or host).split(".")[0]
    trusted = domain_popularity(host) > 0 and not is_free_hosting(host)
    br = [] if trusted else sorted(b for b in BRANDS if b in host and b not in rd_label)
    if br:
        flags.append(("Brand / service name inside host", ", ".join(br[:4]), "medium"))
    if f["num_subdomains"] >= 3:
        flags.append(("Many sub-domains", f"{f['num_subdomains']} levels", "medium"))
    if host.count("-") >= 2:
        flags.append(("Hyphen-heavy host", f"{host.count('-')} hyphens", "info"))
    if f["host_digit_ratio"] > 0.2:
        flags.append(("Digit-heavy host", f"{f['host_digit_ratio']:.0%} digits", "info"))
    if f["url_length"] > 90:
        flags.append(("Very long URL", f"{f['url_length']} chars", "info"))
    if not flags:
        flags.append(("No rule-based red flags", "decision rests on learned patterns", "info"))
    if trusted:   # lure words on a well-known site are normal (e.g. paypal.com/signin)
        flags = [(n, d, "info" if n == "Credential-lure keywords" else sev) for n, d, sev in flags]
    pop = domain_popularity(host)
    if pop and not is_free_hosting(host):
        top = {5: "1k", 4: "5k", 3: "10k", 2: "50k", 1: "100k"}[pop]
        flags.insert(0, ("Well-known domain", f"in Chrome's top-{top} sites", "good"))
    return flags


# --------------------------------------------------------------------------- #
_KW_RE = re.compile("|".join(sorted(PHISH_KEYWORDS | {"signin", "log-in", "wallet"})))


def error_category(url, label):
    """Single, priority-ordered category for an error URL (canonical form)."""
    host = hostname(url)
    rest = url[len(host):] if url.startswith(host) else url.split("/", 1)[-1]
    labels = host.split(".")
    tld = labels[-1] if labels else ""
    has_path = len(rest.strip("/")) > 0
    if label == 1:   # missed phishing  (false negative)
        if is_free_hosting(host):
            return "Hosted on free / cloud platform"
        if _KW_RE.search(url) or any(b in host for b in BRANDS):
            return "Lure keyword present but missed"
        if not has_path and len(labels) <= 2 and not re.search(r"[\d\-]", host):
            return "Clean-looking short domain"
        if has_path:
            return "Ordinary domain + path (compromised site?)"
        return "Plain sub-domain / other"
    # legitimate flagged as phishing  (false positive)
    if "?" in url or (has_path and re.search(r"\d{4,}", rest)):
        return "Deep URL with query / IDs"
    if _KW_RE.search(url):
        return "Benign URL with login/account words"
    if re.search(r"\d", host) or host.count("-") >= 1:
        return "Digits / hyphens in host"
    if tld in SUSPICIOUS_TLDS or len(tld) > 3 or (len(tld) == 2 and tld not in ("uk", "us", "in", "de", "fr", "ca", "au")):
        return "Uncommon / country TLD"
    if not has_path:
        return "Plain unfamiliar domain"
    return "Ordinary path / other"
