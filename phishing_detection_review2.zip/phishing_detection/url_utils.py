"""
url_utils.py
------------
Shared URL canonicalisation + character encoding used by EVERY model
(handcrafted ML, MLP, char-CNN, char-BiLSTM, hybrid) and by the web interface,
so training and inference always see exactly the same string.

Why canonicalise?
  Public phishing corpora leak the label through formatting artefacts:
  e.g. in PhiUSIIL every legitimate URL is "https://www.<domain>" while phishing
  URLs are a mix of http/https, with/without "www". A model can then score ~99%
  just by looking at "https://www." -- it learns the *dataset*, not phishing.
  We therefore strip the scheme and a leading "www." and lower-case the host.
  (HTTPS is not a reliable phishing signal anyway: most phishing sites now
  have valid TLS certificates.)
"""
import re

import numpy as np

_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://")
_WWW_RE = re.compile(r"^www\d{0,2}\.", re.IGNORECASE)

# ---- character vocabulary (fixed, no fitting needed) --------------------- #
PAD_IDX, UNK_IDX = 0, 1
_PRINTABLE = [chr(c) for c in range(32, 127)]          # 95 printable ASCII
CHAR2IDX = {ch: i + 2 for i, ch in enumerate(_PRINTABLE)}
VOCAB_SIZE = len(CHAR2IDX) + 2                           # + PAD + UNK = 97
MAX_LEN = 256                                            # covers ~99.5% of URLs (was 160)


def canonicalize(url: str) -> str:
    """Scheme-less, www-less, lower-cased-host form of a URL."""
    u = str(url).strip()
    u = _SCHEME_RE.sub("", u)
    u = _WWW_RE.sub("", u)
    # split host from the rest (path / query / fragment)
    m = re.match(r"^([^/?#]*)(.*)$", u)
    host, rest = (m.group(1), m.group(2)) if m else (u, "")
    u = host.lower() + rest
    return u.rstrip("/")


def hostname(url: str) -> str:
    """Host part of a (canonical or raw) URL, without userinfo or port."""
    c = canonicalize(url)
    host = re.match(r"^([^/?#]*)", c).group(1)
    host = host.split("@")[-1]
    host = host.split(":")[0]
    return host


def encode_chars(urls, max_len: int = MAX_LEN) -> np.ndarray:
    """Map canonical URL strings -> int matrix [n, max_len] (0 = padding)."""
    out = np.zeros((len(urls), max_len), dtype=np.int64)
    for i, u in enumerate(urls):
        idx = [CHAR2IDX.get(ch, UNK_IDX) for ch in str(u)[:max_len]]
        out[i, :len(idx)] = idx
    return out


if __name__ == "__main__":
    for t in ["HTTPS://WWW.PayPal.com/", "http://secure-login.paypa1.xyz/verify?id=9",
              "github.com/features", "http://user@1.2.3.4:8080/x"]:
        print(f"{t:45s} -> {canonicalize(t):35s} host={hostname(t)}")
