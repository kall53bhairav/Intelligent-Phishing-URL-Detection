"""
dl_models.py
------------
Deep-learning models for Review 2 (PyTorch).

  FeatureMLP   - MLP on the SAME handcrafted features used by the classic ML
                 models  -> isolates the effect of a deep classifier.
  CharCNN      - character-level CNN on the raw (canonical) URL string
                 -> learned representation, no feature engineering.
  CharBiLSTM   - character-level bidirectional LSTM on the raw URL
                 -> learned sequential representation.
  HybridCNN    - CharCNN branch + handcrafted-feature branch fused before the
                 classifier head -> tests whether the two views are complementary.

All models share one interface:  model(chars, feats) -> logits  (shape [B]).
"""
import copy
import math
import time

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score

from url_utils import PAD_IDX, VOCAB_SIZE

torch.set_num_threads(max(1, torch.get_num_threads()))


# --------------------------------------------------------------------------- #
# Models
# --------------------------------------------------------------------------- #
class CharCNN(nn.Module):
    """Embedding -> parallel Conv1d (k=3,5,7) -> masked global max-pool -> MLP."""

    def __init__(self, vocab=VOCAB_SIZE, emb=48, filters=128, kernels=(3, 5, 7),
                 hidden=128, dropout=0.35, **_):
        super().__init__()
        self.emb = nn.Embedding(vocab, emb, padding_idx=PAD_IDX)
        self.convs = nn.ModuleList(
            [nn.Conv1d(emb, filters, k, padding=k // 2) for k in kernels])
        self.out_dim = filters * len(kernels)
        self.head = nn.Sequential(nn.Dropout(dropout),
                                  nn.Linear(self.out_dim, hidden), nn.ReLU(),
                                  nn.Dropout(dropout), nn.Linear(hidden, 1))

    def encode(self, chars):
        mask = (chars != PAD_IDX).unsqueeze(1)                 # [B,1,L]
        e = self.emb(chars).transpose(1, 2)                    # [B,E,L]
        pooled = []
        L = chars.size(1)
        for conv in self.convs:
            h = torch.relu(conv(e)[:, :, :L]).masked_fill(~mask, -1e4)  # ignore padding
            pooled.append(h.max(dim=2).values)
        return torch.cat(pooled, dim=1)                         # [B, 3*filters]

    def forward(self, chars, feats=None):
        return self.head(self.encode(chars)).squeeze(1)


class CharBiLSTM(nn.Module):
    """Embedding -> BiLSTM (packed) -> [max-pool ; mean-pool] -> MLP."""

    def __init__(self, vocab=VOCAB_SIZE, emb=48, hidden=96, fc=128, dropout=0.35, **_):
        super().__init__()
        self.emb = nn.Embedding(vocab, emb, padding_idx=PAD_IDX)
        self.lstm = nn.LSTM(emb, hidden, batch_first=True, bidirectional=True)
        self.out_dim = 4 * hidden
        self.head = nn.Sequential(nn.Dropout(dropout),
                                  nn.Linear(self.out_dim, fc), nn.ReLU(),
                                  nn.Dropout(dropout), nn.Linear(fc, 1))

    def encode(self, chars):
        lengths = (chars != PAD_IDX).sum(1).clamp(min=1)
        e = self.emb(chars)
        packed = nn.utils.rnn.pack_padded_sequence(
            e, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out, _ = self.lstm(packed)
        out, _ = nn.utils.rnn.pad_packed_sequence(
            out, batch_first=True, total_length=chars.size(1))
        mask = (chars != PAD_IDX).unsqueeze(2)
        mx = out.masked_fill(~mask, -1e4).max(dim=1).values
        mean = (out * mask).sum(1) / lengths.unsqueeze(1)
        return torch.cat([mx, mean], dim=1)

    def forward(self, chars, feats=None):
        return self.head(self.encode(chars)).squeeze(1)


class FeatureMLP(nn.Module):
    """3-layer MLP on standardised handcrafted features."""

    def __init__(self, n_feats, hidden=(128, 64), dropout=0.2, **_):
        super().__init__()
        layers, d = [], n_feats
        for h in hidden:
            layers += [nn.Linear(d, h), nn.BatchNorm1d(h), nn.ReLU(), nn.Dropout(dropout)]
            d = h
        layers.append(nn.Linear(d, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, chars=None, feats=None):
        return self.net(feats).squeeze(1)


class HybridCNN(nn.Module):
    """CharCNN representation  ++  handcrafted-feature embedding  -> head."""

    def __init__(self, n_feats, emb=48, filters=128, kernels=(3, 5, 7),
                 feat_hidden=64, hidden=128, dropout=0.35, **_):
        super().__init__()
        self.cnn = CharCNN(emb=emb, filters=filters, kernels=kernels)
        self.fbranch = nn.Sequential(nn.Linear(n_feats, feat_hidden),
                                     nn.BatchNorm1d(feat_hidden), nn.ReLU())
        self.head = nn.Sequential(nn.Dropout(dropout),
                                  nn.Linear(self.cnn.out_dim + feat_hidden, hidden),
                                  nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden, 1))

    def forward(self, chars, feats):
        z = torch.cat([self.cnn.encode(chars), self.fbranch(feats)], dim=1)
        return self.head(z).squeeze(1)


MODEL_CLASSES = {"FeatureMLP": FeatureMLP, "CharCNN": CharCNN,
                 "CharBiLSTM": CharBiLSTM, "HybridCNN": HybridCNN}
USES_CHARS = {"FeatureMLP": False, "CharCNN": True, "CharBiLSTM": True, "HybridCNN": True}
USES_FEATS = {"FeatureMLP": True, "CharCNN": False, "CharBiLSTM": False, "HybridCNN": True}


def n_params(model):
    return sum(p.numel() for p in model.parameters())


# --------------------------------------------------------------------------- #
# Batching: length-bucketed batches + trimming to the longest URL in a batch
# --------------------------------------------------------------------------- #
def _batches(n, lengths, batch_size, shuffle, rng):
    idx = np.arange(n)
    if shuffle:
        rng.shuffle(idx)
    if lengths is None:
        return [idx[i:i + batch_size] for i in range(0, n, batch_size)]
    chunk = batch_size * 50
    out = []
    for c in range(0, n, chunk):
        part = idx[c:c + chunk]
        part = part[np.argsort(lengths[part], kind="stable")]
        out += [part[i:i + batch_size] for i in range(0, len(part), batch_size)]
    if shuffle:
        rng.shuffle(out)
    return out


def _to_tensors(b, chars, feats, lengths):
    xc = xf = None
    if chars is not None:
        L = max(1, int(lengths[b].max()))
        xc = torch.from_numpy(chars[b, :L])
    if feats is not None:
        xf = torch.from_numpy(feats[b])
    return xc, xf


@torch.no_grad()
def predict_proba(model, chars=None, feats=None, batch_size=1024):
    model.eval()
    n = len(chars) if chars is not None else len(feats)
    lengths = (chars != PAD_IDX).sum(1) if chars is not None else None
    out = np.zeros(n, dtype=np.float32)
    for b in _batches(n, lengths, batch_size, False, None):
        xc, xf = _to_tensors(b, chars, feats, lengths)
        out[b] = torch.sigmoid(model(xc, xf)).numpy()
    return out


def train_model(model, tr, va, epochs=12, batch_size=256, lr=2e-3,
                weight_decay=1e-4, patience=3, seed=42, log=print):
    """tr / va = dict(chars=np.int64[n,L] | None, feats=np.float32[n,d] | None, y=np.int[n]).
    Early stopping on validation loss; returns (best_model, history)."""
    torch.manual_seed(seed)
    rng = np.random.RandomState(seed)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=1)
    lossf = nn.BCEWithLogitsLoss()

    ytr = tr["y"].astype(np.float32)
    ltr = (tr["chars"] != PAD_IDX).sum(1) if tr["chars"] is not None else None
    n = len(ytr)

    best, best_loss, bad, hist = None, math.inf, 0, []
    for ep in range(1, epochs + 1):
        model.train()
        t0, tot = time.time(), 0.0
        for b in _batches(n, ltr, batch_size, True, rng):
            xc, xf = _to_tensors(b, tr["chars"], tr["feats"], ltr)
            yb = torch.from_numpy(ytr[b])
            opt.zero_grad()
            loss = lossf(model(xc, xf), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            tot += loss.item() * len(b)
        p = predict_proba(model, va["chars"], va["feats"])
        pc = np.clip(p, 1e-7, 1 - 1e-7)
        vy = va["y"]
        vloss = float(-np.mean(vy * np.log(pc) + (1 - vy) * np.log(1 - pc)))
        vauc = float(roc_auc_score(vy, p))
        vacc = float(((p >= 0.5) == vy).mean())
        sched.step(vloss)
        hist.append({"epoch": ep, "train_loss": tot / n, "val_loss": vloss,
                     "val_auc": vauc, "val_acc": vacc, "secs": time.time() - t0})
        log(f"    epoch {ep:2d}  train_loss={tot/n:.4f}  val_loss={vloss:.4f}  "
            f"val_auc={vauc:.4f}  val_acc={vacc:.4f}  ({time.time()-t0:.0f}s)")
        if vloss < best_loss - 1e-4:
            best_loss, best, bad = vloss, copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
            if bad >= patience:
                log(f"    early stop (best val_loss={best_loss:.4f})")
                break
    model.load_state_dict(best)
    return model, hist


# --------------------------------------------------------------------------- #
# Save / load
# --------------------------------------------------------------------------- #
def save_dl(model, kind, kwargs, path):
    torch.save({"kind": kind, "kwargs": kwargs, "state_dict": model.state_dict()}, path)


def load_dl(path):
    ck = torch.load(path, map_location="cpu", weights_only=False)
    m = MODEL_CLASSES[ck["kind"]](**ck["kwargs"])
    m.load_state_dict(ck["state_dict"])
    m.eval()
    return m, ck["kind"]
