"""
prepare_real_data.py
--------------------
Builds the REAL-WORLD benchmark used in Review 2 and audits it for shortcut
artefacts.

Sources (public, peer-reviewed / widely used):
  * PhiUSIIL Phishing URL Dataset  (Prasad & Chandra, Computers & Security 2024,
    UCI repository id 967) -- 235,795 URLs; label 0 = phishing, 1 = legitimate.
  * Malicious URLs dataset (Kaggle, M. Siddhartha 2021, 651,191 URLs) -- we use
    only its "benign" URLs, which carry real paths/queries (PhiUSIIL's
    legitimate URLs are home pages only).

  * Phishing.Database ACTIVE list (github.com/mitchellkrogza/Phishing.Database) --
    ~790k phishing URLs still online, aggregated from public feeds; adds recent
    campaigns (pages.dev, workers.dev, duckdns, ...).            [accuracy upgrade]
  * Chrome UX Report top-1M origins (CrUX, via github.com/zakird/crux-top-lists) --
    real, currently-visited sites incl. login/mail sub-domains
    (accounts.google.com, login.microsoftonline.com, ...).       [accuracy upgrade]

Composite benchmark (label 1 = phishing, 0 = legitimate):
    phishing   : PhiUSIIL phishing  +  Phishing.Database active URLs
    legitimate : PhiUSIIL home pages + Kaggle benign deep URLs + CrUX top-1M origins
Hosts of the live OpenPhish feed and of the familiar-sites sanity list
(data/sanity/) are excluded from every split, so sanity_check.py measures
behaviour on sites the models have never seen.
Processing:
    1. canonicalise (strip scheme + "www.", lower-case host)   [url_utils.py]
    2. de-duplicate; drop URLs that appear with both labels
    3. cap every hostname at 3 URLs (stops youtube.com etc. dominating)
    4. stratified sample
    5. HOSTNAME-DISJOINT train/val/test split (70/10/20) with
       StratifiedGroupKFold -> no host is in two splits, so models cannot
       score by memorising domains.

Usage:
    python prepare_real_data.py                       # uses data/raw/*.csv
    python prepare_real_data.py --phiusiil P.csv --kaggle K.csv
Raw files (not shipped -- 100 MB):
    data/raw/phiusiil.csv          (UCI: PhiUSIIL_Phishing_URL_Dataset.csv)
    data/raw/malicious_phish.csv   (Kaggle: sid321axn/malicious-urls-dataset)
"""
import argparse
import json
import os
import urllib.request

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import StratifiedGroupKFold, train_test_split

from url_utils import canonicalize, hostname

OUT_PATH = "data/real_urls.csv"
RESULTS_DIR = "results"
MIRRORS = {  # convenience mirrors of the official files (GitHub LFS)
    "phiusiil": "https://media.githubusercontent.com/media/techietinker1/"
                "Phishing-URL-Detection/HEAD/PhiUSIIL_Phishing_URL_Dataset.csv",
    "kaggle": "https://media.githubusercontent.com/media/knsangmor/"
              "PhishGuard_Ghana/HEAD/malicious_phish.csv",
    "pdb": "https://raw.githubusercontent.com/mitchellkrogza/Phishing.Database/"
           "master/phishing-links-ACTIVE.txt",
    "crux": "https://raw.githubusercontent.com/zakird/crux-top-lists/main/data/global/current.csv.gz",
}


def _ensure(path, key):
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        print(f"[data] downloading {key} -> {path}")
        urllib.request.urlretrieve(MIRRORS[key], path)
    return path


def load_extra(pdb_path, crux_path):
    pdb = [l.strip() for l in open(_ensure(pdb_path, "pdb"), encoding="utf-8", errors="ignore")]
    pdb = pd.DataFrame({"url_raw": [u for u in pdb if u.lower().startswith(("http://", "https://"))],
                        "label": 1, "source": "PhishDB-active"})
    crux = pd.read_csv(_ensure(crux_path, "crux"))
    crux = pd.DataFrame({"url_raw": crux["origin"].astype(str), "label": 0, "source": "CrUX-top1M"})
    return pdb, crux


def load_sources(phi_path, kag_path):
    phi = pd.read_csv(_ensure(phi_path, "phiusiil"), encoding="utf-8-sig",
                      usecols=["URL", "label"])
    phi = pd.DataFrame({
        "url_raw": phi["URL"].astype(str),
        "label": (phi["label"] == 0).astype(int),         # 1 = phishing
        "source": np.where(phi["label"] == 0, "PhiUSIIL-phish", "PhiUSIIL-legit"),
    })
    kag = pd.read_csv(_ensure(kag_path, "kaggle"))
    kag = kag[kag["type"] == "benign"]
    kag = pd.DataFrame({"url_raw": kag["url"].astype(str), "label": 0,
                        "source": "Kaggle-benign"})
    return phi, kag


# --------------------------------------------------------------------------- #
# Shortcut audit: can 4 trivial formatting flags predict the label?
# --------------------------------------------------------------------------- #
def _flags(raw_urls):
    s = pd.Series(raw_urls).astype(str)
    no_scheme = s.str.replace(r"^[a-zA-Z]+://", "", regex=True)
    return pd.DataFrame({
        "starts_https": s.str.lower().str.startswith("https://"),
        "has_www": no_scheme.str.lower().str.startswith("www."),
        "has_path_or_query": no_scheme.str.rstrip("/").str.contains(r"[/?]"),
        "has_scheme": s.str.contains("://", regex=False),
    }).astype(int)


def shortcut_score(raw_urls, labels, seed=42):
    F = _flags(raw_urls)
    Xtr, Xte, ytr, yte = train_test_split(F, labels, test_size=0.25,
                                          stratify=labels, random_state=seed)
    lr = LogisticRegression(max_iter=1000).fit(Xtr, ytr)
    p = lr.predict(Xte)
    rates = F.groupby(np.asarray(labels)).mean().T
    rates.columns = ["legit_rate", "phish_rate"]
    return {"f1": f1_score(yte, p), "accuracy": accuracy_score(yte, p)}, rates


SIZES = {"PhiUSIIL-phish": 50000, "PhishDB-active": 50000,
         "PhiUSIIL-legit": 35000, "Kaggle-benign": 35000, "CrUX-top1M": 30000}


def build(phi_path, kag_path, pdb_path, crux_path, sizes=SIZES, host_cap=3, seed=42):
    rng = np.random.RandomState(seed)
    phi, kag = load_sources(phi_path, kag_path)
    pdb, crux = load_extra(pdb_path, crux_path)
    print(f"[data] PhiUSIIL={len(phi)} (phish={phi.label.sum()})  Kaggle benign={len(kag)}  "
          f"PhishDB active={len(pdb)}  CrUX={len(crux)}")

    # ---- audit the ORIGINAL PhiUSIIL formatting ----------------------------
    audit_raw = phi.sample(60000, random_state=seed)
    raw_score, raw_rates = shortcut_score(audit_raw.url_raw, audit_raw.label)

    # ---- canonicalise, dedupe, cap per host --------------------------------
    df = pd.concat([phi, kag, pdb, crux], ignore_index=True)
    df["url"] = df["url_raw"].map(canonicalize)
    df["host"] = df["url"].map(hostname)
    df = df[(df["host"].str.len() >= 4) & df["host"].str.contains(".", regex=False)]
    df = df[df["url"].str.len() <= 2000]
    conflict = df.groupby("url")["label"].nunique()
    df = df[~df["url"].isin(conflict[conflict > 1].index)]
    df = df.drop_duplicates("url")
    # keep the live feed + familiar-site sanity hosts completely unseen
    excl = set()
    for f in ["data/sanity/openphish_2026-11-13.txt", "data/sanity/familiar_legit_urls.txt"]:
        if os.path.exists(f):
            excl |= {hostname(l.strip()) for l in open(f) if l.strip()}
    df = df[~df["host"].isin(excl)]
    df = (df.sample(frac=1, random_state=seed)
            .groupby("host", group_keys=False).head(host_cap))

    parts = []
    for src, n in sizes.items():
        pool = df[df["source"] == src]
        parts.append(pool.sample(min(n, len(pool)), random_state=seed))
    data = pd.concat(parts).sample(frac=1, random_state=seed).reset_index(drop=True)

    # ---- hostname-disjoint split: 70 / 10 / 20 -----------------------------
    data["split"] = "train"
    sgkf = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    _, test_idx = next(sgkf.split(data, data["label"], groups=data["host"]))
    data.loc[test_idx, "split"] = "test"
    rest = data[data["split"] == "train"]
    sgkf8 = StratifiedGroupKFold(n_splits=8, shuffle=True, random_state=seed)
    _, val_local = next(sgkf8.split(rest, rest["label"], groups=rest["host"]))
    data.loc[rest.index[val_local], "split"] = "val"

    # sanity: no host in two splits
    hs = data.groupby("host")["split"].nunique()
    assert (hs == 1).all(), "host leakage between splits!"

    # ---- audit the CANONICAL composite -------------------------------------
    can_score, can_rates = shortcut_score(data["url"], data["label"])

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)
    data[["url", "url_raw", "host", "label", "source", "split"]].to_csv(OUT_PATH, index=False)

    audit = pd.DataFrame([
        {"dataset": "PhiUSIIL as published (raw URLs)", **raw_score},
        {"dataset": "Our composite (canonical URLs)", **can_score},
    ])
    audit.to_csv(os.path.join(RESULTS_DIR, "r2_shortcut_audit.csv"), index=False)
    rates = pd.concat({"phiusiil_raw": raw_rates, "composite_canonical": can_rates}, axis=1)
    rates.to_csv(os.path.join(RESULTS_DIR, "r2_shortcut_flag_rates.csv"))

    from reputation import domain_popularity
    data["popular"] = data["host"].map(domain_popularity) > 0
    pop = data.groupby("source")["popular"].mean()
    pop.to_csv(os.path.join(RESULTS_DIR, "r2_popularity_by_source.csv"))
    print("\nshare of URLs whose domain is in Chrome's top-100k, by source:\n", pop.round(3).to_string())
    summ = (data.groupby(["split", "source"]).size().unstack(fill_value=0))
    summ.to_csv(os.path.join(RESULTS_DIR, "r2_dataset_summary.csv"))
    stats = {
        "n_total": int(len(data)),
        "n_phish": int(data.label.sum()),
        "n_legit": int((data.label == 0).sum()),
        "n_hosts": int(data.host.nunique()),
        "split_sizes": data.split.value_counts().to_dict(),
        "median_len_phish": float(data[data.label == 1].url.str.len().median()),
        "median_len_legit": float(data[data.label == 0].url.str.len().median()),
    }
    with open(os.path.join(RESULTS_DIR, "r2_dataset_stats.json"), "w") as f:
        json.dump(stats, f, indent=2)

    print("\n=== SHORTCUT AUDIT (LogReg on 4 formatting flags) ===")
    print(audit.round(4).to_string(index=False))
    print("\nflag rates by class:\n", rates.round(3).to_string())
    print("\n=== COMPOSITE DATASET ===")
    print(summ.to_string())
    print(json.dumps(stats, indent=2))
    return data


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--phiusiil", default="data/raw/phiusiil.csv")
    ap.add_argument("--kaggle", default="data/raw/malicious_phish.csv")
    ap.add_argument("--phishdb", default="data/raw/phishing_database_active.txt")
    ap.add_argument("--crux", default="data/raw/crux_global_top1m.csv.gz")
    a = ap.parse_args()
    build(a.phiusiil, a.kaggle, a.phishdb, a.crux)
