"""
learning_curve.py
-----------------
How does each family improve as the number of training URLs grows?
Trains the best handcrafted model (Gradient Boosting), the handcrafted MLP, the
learned char-CNN and the char n-gram TF-IDF reference on nested random subsets of
the training split (1/16 ... all) and scores them on the SAME test split.

Output: results/r2_learning_curve.csv
"""
import time

import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from dl_models import CharCNN, FeatureMLP, predict_proba, train_model
from run_review2 import SEED, hc_matrix
from url_utils import encode_chars
import json

FRACS = [1 / 16, 1 / 8, 1 / 4, 1 / 2, 1.0]


def main():
    df = pd.read_csv("data/real_urls.csv")
    tr, va, te = (df[df.split == s].reset_index(drop=True) for s in ("train", "val", "test"))
    sel = json.load(open("models/meta.json"))["selected_features"]
    Xtr, Xva, Xte = hc_matrix(tr.url)[sel], hc_matrix(va.url)[sel], hc_matrix(te.url)[sel]
    Ctr, Cva, Cte = encode_chars(tr.url), encode_chars(va.url), encode_chars(te.url)
    ytr, yva, yte = tr.label.values, va.label.values, te.label.values
    perm = np.random.RandomState(SEED).permutation(len(tr))
    rows = []
    for f in FRACS:
        idx = perm[:int(len(tr) * f)]
        n = len(idx)
        res = {}
        t0 = time.time()
        gb = HistGradientBoostingClassifier(max_iter=400, learning_rate=0.08,
                                            max_leaf_nodes=63, random_state=SEED)
        res["Gradient Boosting"] = gb.fit(Xtr.iloc[idx], ytr[idx]).predict_proba(Xte)[:, 1]
        tf = Pipeline([("tfidf", TfidfVectorizer(analyzer="char", ngram_range=(2, 5), min_df=3,
                                                 max_features=300000, sublinear_tf=True)),
                       ("clf", LogisticRegression(C=5, max_iter=3000))])
        res["Char n-gram TF-IDF + LR"] = tf.fit(tr.url.iloc[idx], ytr[idx]).predict_proba(te.url)[:, 1]
        sc = StandardScaler().fit(Xtr.iloc[idx])
        z = lambda X: np.clip(sc.transform(X), -6, 6).astype(np.float32)
        torch.manual_seed(SEED)
        mlp, _ = train_model(FeatureMLP(n_feats=len(sel)),
                             {"chars": None, "feats": z(Xtr.iloc[idx]), "y": ytr[idx]},
                             {"chars": None, "feats": z(Xva), "y": yva},
                             epochs=20, lr=1e-3, log=lambda s: None)
        res["MLP"] = predict_proba(mlp, None, z(Xte))
        torch.manual_seed(SEED)
        cnn, h = train_model(CharCNN(), {"chars": Ctr[idx], "feats": None, "y": ytr[idx]},
                             {"chars": Cva, "feats": None, "y": yva}, epochs=20, lr=2e-3,
                             log=lambda s: None)
        res["Char-CNN"] = predict_proba(cnn, Cte, None)
        for m, p in res.items():
            rows.append({"n_train": n, "model": m, "f1": f1_score(yte, p >= 0.5),
                         "roc_auc": roc_auc_score(yte, p)})
        print(f"n={n:6d}  " + "  ".join(f"{m}: F1={f1_score(yte, p >= .5):.4f}"
                                         for m, p in res.items()) + f"  ({time.time()-t0:.0f}s)",
              flush=True)
    pd.DataFrame(rows).to_csv("results/r2_learning_curve.csv", index=False)


if __name__ == "__main__":
    main()
