"""
predictor.py
------------
Loads the trained Review-2 models from models/ and scores URLs.
Used by the Streamlit interface (app.py) and usable from the command line:

    python predictor.py "http://secure-login.paypa1-verify.xyz/account"
    python predictor.py github.com/features  https://bit.ly/3abc
"""
import json
import os
import sys

import joblib
import numpy as np
import pandas as pd

from dl_models import USES_CHARS, USES_FEATS, load_dl, predict_proba
from explain import char_occlusion, red_flags
from run_review2 import hc_matrix
from url_utils import canonicalize, encode_chars

DISPLAY_ORDER = ["Hybrid CNN+Features", "Char-CNN", "Char-BiLSTM", "MLP",
                 "Gradient Boosting", "Random Forest", "Logistic Regression"]
FAMILY = {"Hybrid CNN+Features": "Hybrid DL", "Char-CNN": "Learned DL",
          "Char-BiLSTM": "Learned DL", "MLP": "Handcrafted DL",
          "Gradient Boosting": "Handcrafted ML", "Random Forest": "Handcrafted ML",
          "Logistic Regression": "Handcrafted ML"}


def risk_band(p):
    if p >= 0.70:
        return "HIGH"
    if p >= 0.30:
        return "MEDIUM"
    return "LOW"


class PhishPredictor:
    def __init__(self, model_dir="models"):
        with open(os.path.join(model_dir, "meta.json")) as f:
            self.meta = json.load(f)
        self.selected = self.meta["selected_features"]
        self.scaler = joblib.load(os.path.join(model_dir, "feature_scaler.joblib"))
        self.models = {}
        for name, fn in self.meta["ml_files"].items():
            try:
                self.models[name] = ("ml", joblib.load(os.path.join(model_dir, fn)))
            except Exception as e:  # e.g. different scikit-learn version
                print(f"[predictor] could not load {fn} ({e.__class__.__name__}); retraining {name}")
                self.models[name] = ("ml", self._retrain_ml(name))
        for name, fn in self.meta["dl_files"].items():
            m, kind = load_dl(os.path.join(model_dir, fn))
            self.models[name] = ("dl", (m, kind))
        self.names = [n for n in DISPLAY_ORDER if n in self.models]

    def _retrain_ml(self, name, data="data/real_urls.csv"):
        """Fallback when a pickled sklearn model cannot be loaded."""
        from sklearn.ensemble import HistGradientBoostingClassifier
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        df = pd.read_csv(data)
        tr = df[df.split == "train"]
        X = hc_matrix(tr.url)[self.selected]
        if name == "Gradient Boosting":
            m = Pipeline([("clf", HistGradientBoostingClassifier(
                max_iter=400, learning_rate=0.08, max_leaf_nodes=63, random_state=42))])
        else:
            m = Pipeline([("scaler", StandardScaler()),
                          ("clf", LogisticRegression(max_iter=2000, random_state=42))])
        return m.fit(X, tr.label.values)

    # ------------------------------------------------------------------ #
    def _inputs(self, urls):
        canon = [canonicalize(u) for u in urls]
        X = hc_matrix(canon)[self.selected]
        F = np.clip(self.scaler.transform(X), -6, 6).astype(np.float32)
        C = encode_chars(canon)
        return canon, X, F, C

    def _score(self, name, X, F, C):
        kind, obj = self.models[name]
        if kind == "ml":
            return obj.predict_proba(X)[:, 1]
        m, k = obj
        return predict_proba(m, C if USES_CHARS[k] else None, F if USES_FEATS[k] else None)

    def predict_all(self, urls):
        """DataFrame: one row per URL, one column per model (= P(phishing))."""
        urls = [u for u in urls if str(u).strip()]
        canon, X, F, C = self._inputs(urls)
        out = pd.DataFrame({"url": urls, "canonical": canon})
        for n in self.names:
            out[n] = self._score(n, X, F, C)
        return out

    def saliency(self, url, name):
        """Char-level occlusion saliency for a char-based model (else None)."""
        kind, obj = self.models[name]
        if kind != "dl" or not USES_CHARS[obj[1]]:
            return None
        m, k = obj
        canon, _, F, _ = self._inputs([url])
        if USES_FEATS[k]:
            fn = lambda Cm: predict_proba(m, Cm, np.repeat(F, len(Cm), axis=0))
        else:
            fn = lambda Cm: predict_proba(m, Cm, None)
        base, scores = char_occlusion(fn, canon[0])
        return canon[0], base, scores

    def threshold(self, name, mode="balanced"):
        return self.meta["thresholds_1pct_fpr"].get(name, 0.5) if mode == "low_fpr" else 0.5

    @staticmethod
    def flags(url):
        return red_flags(url)


if __name__ == "__main__":
    urls = sys.argv[1:] or ["https://www.github.com/features",
                            "http://secure-login.paypa1-verify.xyz/account/update",
                            "metamask-wallet-restore.web.app"]
    pp = PhishPredictor()
    res = pp.predict_all(urls)
    pd.set_option("display.width", 200)
    print(res.drop(columns=["url"]).round(3).to_string(index=False))
